# 📥 كيفية تحميل ملفات المشروع

## 📍 أين توجد الملفات المضغوطة؟

الملفات موجودة في المسار:
```
/tmp/
```

### الملفات المتاحة:

1. **madmoonstore-bot.tar.gz** (72KB) - الأسرع ⚡
   - المسار: `/tmp/madmoonstore-bot.tar.gz`
   - الملفات الأساسية فقط

2. **madmoonstore-lite.tar.gz** (28MB) - الأنسب 🎯
   - المسار: `/tmp/madmoonstore-lite.tar.gz`
   - جميع الملفات بدون node_modules

3. **madmoonstore-full.tar.gz** (56MB) - الكامل
   - المسار: `/tmp/madmoonstore-full.tar.gz`
   - جميع الملفات مع node_modules

---

## 🚀 كيفية التحميل والنشر:

### الطريقة 1: من هذا النظام مباشرة

#### الخطوة 1: نسخ الملف
```bash
# نسخ الملف إلى المجلد الحالي
cp /tmp/madmoonstore-lite.tar.gz .
```

#### الخطوة 2: فك الضغط
```bash
# فك الضغط
tar -xzf madmoonstore-lite.tar.gz

# الدخول إلى المجلد
cd madmoonstore-bot
```

#### الخطوة 3: التثبيت والبناء
```bash
# تثبيت التبعيات
npm install

# البناء
npm run build
```

#### الخطوة 4: النشر على Netlify
```bash
# تثبيت Netlify CLI
npm install -g netlify-cli

# تسجيل الدخول
netlify login

# النشر
netlify deploy --prod
```

---

### الطريقة 2: تحميل الملفات يدوياً

#### إذا كنت تستخدم هذا النظام مباشرة:

**الخطوة 1: تحميل الملف**
```bash
# نسخ الملف من /tmp/ إلى المجلد الحالي
cp /tmp/madmoonstore-lite.tar.gz .
```

**الخطوة 2: فك الضغط**
```bash
tar -xzf madmoonstore-lite.tar.gz
```

**الخطوة 3: النشر**
```bash
cd madmoonstore-bot
npm install -g netlify-cli
netlify login
netlify deploy --prod
```

---

### الطريقة 3: استخدام GitHub (الأفضل) ⭐

#### الخطوة 1: إنشاء مستودع GitHub
1. اذهب إلى: https://github.com/new
2. أدخل اسم: `madmoonstore-bot`
3. اضغط "Create repository"

#### الخطوة 2: رفع الملفات

**أ) باستخدام Git من هذا النظام:**
```bash
# انتقل إلى المجلد
cd madmoonstore-bot

# تهيئة Git
git init
git add .
git commit -m "Initial commit"

# ربط المستودع
git remote add origin https://github.com/YOUR_USERNAME/madmoonstore-bot.git

# رفع الملفات
git push -u origin main
```

**ب) يدوياً عبر GitHub:**
1. افتح GitHub.com
2. اذهب للمستودع الذي أنشأته
3. اضغط "Upload files"
4. افتح المجلد `madmoonstore-bot`
5. اسحب جميع الملفات وأفلها
6. اضغط "Commit changes"

#### الخطوة 3: النشر على Netlify
1. اذهب إلى: https://app.netlify.com/start
2. اختر "GitHub"
3. اسمح بالوصول
4. اختر مستودع `madmoonstore-bot`
5. اضغط "Deploy site"
6. انتظر النشر (1-2 دقيقة)

---

## ⚙️ بعد النشر:

### 1. إضافة متغيرات البيئة
اذهب إلى: Site settings → Environment variables

أضف:
```
TELEGRAM_BOT_TOKEN = 8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU
SMM_API_URL = https://smmsharks.com/api/v2
SMM_API_KEY = 01b815347b66b2fe9527d631b98bbb3a
NEXT_PUBLIC_SUPABASE_URL = https://zdjzdgxwhtjedknrzxmx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY = sb_publishable_VGUQhIqd0T6kN-PVN8I1gw_W7ZYO3-B
SUPABASE_SERVICE_ROLE_KEY = sb_secret_Yg6OV3hl7Ie1fYN0xuebcQ_nIsnBu4p
VITE_SUPABASE_URL = https://zdjzdgxwhtjedknrzxmx.supabase.co
VITE_SUPABASE_ANON_KEY = sb_publishable_VGUQhIqd0T6kN-PVN8I1gw_W7ZYO3-B
```

### 2. إعداد Webhook
استبدل `YOUR_SITE_URL` برابط موقعك:

```bash
curl -F "url=https://YOUR_SITE_URL.netlify.app/api/telegram" \
  https://api.telegram.org/bot8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU/setWebhook
```

### 3. اختبار البوت
1. افتح تيليجرام
2. ابحث عن @MadmoonStore_bot
3. اكتب `/start`
4. جرب الخدمات!

---

## ✅ التحقق من النشر:

### اختبار الموقع:
```bash
curl https://YOUR_SITE_URL.netlify.app
```

### اختبار API:
```bash
curl https://YOUR_SITE_URL.netlify.app/api/services
```

### اختبار Webhook:
```bash
curl https://api.telegram.org/bot8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU/getWebhookInfo
```

---

## 🎯 روابط مهمة:

- **الموقع:** `https://YOUR_SITE_URL.netlify.app/`
- **لوحة التحكم:** `https://YOUR_SITE_URL.netlify.app/dashboard`
- **الخدمات:** `https://YOUR_SITE_URL.netlify.app/services`
- **الطلبات:** `https://YOUR_SITE_URL.netlify.app/orders`
- **المستخدمين:** `https://YOUR_SITE_URL.netlify.app/users`
- **الإعدادات:** `https://YOUR_SITE_URL.netlify.app/settings`
- **البوت:** @MadmoonStore_bot

---

## 💡 نصائح:

1. **استخدم madmoonstore-lite.tar.gz** - الأنسب للنشر
2. **استخدم GitHub للنشر** - الأسهل والأسرع
3. **أضف جميع المتغيرات** - ضرورية للعمل
4. **اضبط Webhook** - ضروري للبوت
5. **اختبر كل شيء** - قبل البدء الفعلي

---

## 🎉 مبروك!

الآن لديك كل ما تحتاجه لنشر البوت!

ابدأ في النشر الآن! 🚀
