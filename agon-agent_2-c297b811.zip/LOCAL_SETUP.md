# 🏠 التشغيل المحلي (للاختبار)

## الخطوات:

### 1️⃣ تثبيت المكتبات
```bash
npm install
```

### 2️⃣ إنشاء ملف .env
أنشئ ملف `.env` في مجلد المشروع وأضف:
```
NEXT_PUBLIC_SUPABASE_URL=https://zdjzdgxwhtjedknrzxmx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=sb_publishable_VGUQhIqd0T6kN-PVN8I1gw_W7ZYO3-B
SUPABASE_SERVICE_ROLE_KEY=sb_secret_Yg6OV3hl7Ie1fYN0xuebcQ_nIsnBu4p
VITE_SUPABASE_URL=https://zdjzdgxwhtjedknrzxmx.supabase.co
VITE_SUPABASE_ANON_KEY=sb_publishable_VGUQhIqd0T6kN-PVN8I1gw_W7ZYO3-B
TELEGRAM_BOT_TOKEN=8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU
SMM_API_URL=https://smmsharks.com/api/v2
SMM_API_KEY=01b815347b66b2fe9527d631b98bbb3a
```

### 3️⃣ تشغيل المشروع
```bash
npm run dev
```

### 4️⃣ فتح الموقع
```
http://localhost:5173
```

### 5️⃣ إعداد Webhook للبوت (محلياً)
استخدم ngrok لإعادة توجيه المنفذ:

```bash
# تثبيت ngrok
npm install -g ngrok

# تشغيل ngrok
ngrok http 5173
```

سيظهر رابط مثل: `https://abc123.ngrok.io`

ثم إعداد الـ Webhook:
```bash
curl -F "url=https://abc123.ngrok.io/api/telegram" \
  https://api.telegram.org/bot8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU/setWebhook
```

### 6️⃣ اختبار البوت
1. افتح تيليجرام
2. ابحث عن @MadmoonStore_bot
3. اكتب `/start`

---

## ✅ جاهز للاختبار!
