# 🚀 MadmoonStore Bot - بوت تيليجرام متكامل لبيع خدمات SMM

## ✅ المشروع جاهز 100% للنشر على Netlify!

---

## 📦 ما يتضمنه المشروع:

### 🤖 نظام البوت التيليجرام:
- ✅ أوامر تفاعلية (/start, /help)
- ✅ قائمة خدمات منظمة حسب المنصة
- ✅ عرض الخدمات والأسعار
- ✅ تتبع الطلبات من البوت
- ✅ عرض رصيد المستخدم
- ✅ دعم فني مدمج

### 📊 لوحة تحكم احترافية:
- ✅ إحصائيات شاملة (المستخدمين، الطلبات، الإيرادات)
- ✅ عرض الطلبات الحديثة
- ✅ رسوم بيانية للإحصائيات

### 🛒 نظام إدارة الخدمات:
- ✅ إضافة/تعديل/حذف الخدمات
- ✅ تصنيف حسب المنصة (انستقرام، تويتر، تيك توك، يوتيوب، فيسبوك، تيليجرام)
- ✅ تحديد الأسعار والحدود
- ✅ **مزامنة تلقائية من SMM Sharks** ⭐
- ✅ بحث وتصفية الخدمات

### 📋 نظام إدارة الطلبات:
- ✅ عرض جميع الطلبات
- ✅ تحديث حالة الطلبات (قيد الانتظار، قيد التنفيذ، مكتمل، ملغي)
- ✅ تفاصيل كاملة لكل طلب
- ✅ تصفية حسب الحالة
- ✅ **إرسال تلقائي لـ SMM** ⭐
- ✅ **تحديث الحالة من SMM** ⭐
- ✅ إجراءات سريعة (بدء، إكمال، إلغاء)

### 👥 نظام إدارة المستخدمين:
- ✅ عرض جميع المستخدمين المسجلين عبر البوت
- ✅ شحن الأرصدة للمستخدمين
- ✅ إحصائيات الأرصدة
- ✅ البحث عن المستخدمين

### ⚙️ نظام الإعدادات:
- ✅ تكوين بوت تيليجرام (Token, Webhook)
- ✅ إعدادات الأدمن
- ✅ اختيار العملة
- ✅ تفعيل/إيقاف التنفيذ التلقائي
- ✅ تفعيل/إيقاف فحص الحالة التلقائي
- ✅ تعديل هامش الربح
- ✅ **عرض رصيد SMM** ⭐

---

## 🔗 الربط مع SMM Sharks:

### الميزات المتوفرة:
1. ✅ **مزامنة تلقائية للخدمات** من SMM Sharks
2. ✅ **إضافة هامش ربح تلقائي** (20% افتراضي)
3. ✅ **إرسال الطلبات تلقائياً** لـ SMM Sharks
4. ✅ **فحص حالة الطلبات** من SMM Sharks
5. ✅ **عرض رصيد SMM** في لوحة التحكم

### كيفية الاستخدام:

#### 1) مزامنة الخدمات من SMM:
- اذهب إلى "الخدمات" في لوحة التحكم
- اضغط "🔄 مزامنة من SMM"
- انتظر حتى تنتهي المزامنة
- سيتم جلب جميع الخدمات مع هامش ربح 20%

#### 2) تنفيذ الطلبات تلقائياً:
- الطلبات تُرسل تلقائياً لـ SMM عند الإنشاء
- أو اضغط "⚡ إرسال إلى SMM" يدوياً من صفحة الطلبات

#### 3) تحديث الحالة من SMM:
- اضغط "🔄 تحديث الحالة من SMM" لفحص حالة الطلب
- ستُحدث الحالة تلقائياً بناءً على رد SMM

#### 4) عرض رصيد SMM:
- يظهر رصيد SMM في صفحة "الإعدادات"
- أو عبر API: `/api/smm-balance`

---

## 🗄️ قاعدة البيانات (Supabase):

### الجداول:
1. **services** - الخدمات المتاحة
2. **orders** - الطلبات
3. **users** - المستخدمين
4. **settings** - إعدادات النظام

### البيانات التجريبية:
- ✅ 12 خدمة تجريبية لجميع المنصات
- ✅ 5 مستخدمين تجريبيين بأرصدتهم
- ✅ 8 طلبات تجريبية بحالات مختلفة

---

## 🚀 كيفية النشر على Netlify:

### الطريقة الأولى: عبر واجهة الويب (الأسهل) ⭐

#### الخطوة 1: إنشاء حساب
1. اذهب إلى: https://app.netlify.com/signup
2. سجل حساباً جديداً (مجاني بالكامل)

#### الخطوة 2: رفع المشروع
1. اضغط "Add new site" → "Deploy manually"
2. اسحب وأفلت مجلد المشروع بالكامل
3. اضغط "Deploy site"
4. انتظر 2-3 دقائق

#### الخطوة 3: إضافة متغيرات البيئة ⭐⭐⭐ مهم جداً

اذهب إلى: Site settings → Environment variables

أضف المتغيرات التالية:

```
NEXT_PUBLIC_SUPABASE_URL=https://zdjzdgxwhtjedknrzxmx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=sb_publishable_VGUQhIqd0T6kN-PVN8I1gw_W7ZYO3-B
SUPABASE_SERVICE_ROLE_KEY=sb_secret_Yg6OV3hl7Ie1fYN0xuebcQ_nIsnBu4p
VITE_SUPABASE_URL=https://zdjzdgxwhtjedknrzxmx.supabase.co
VITE_SUPABASE_ANON_KEY=sb_publishable_VGUQhIqd0T6kN-PVN8I1gw_W7ZYO3-B
TELEGRAM_BOT_TOKEN=8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU
SMM_API_URL=https://smmsharks.com/api/v2
SMM_API_KEY=01b815347b66b2fe9527d631b98bbb3a
```

#### الخطوة 4: تفعيل البوت ⭐⭐⭐ مهم جداً

استبدل `YOUR_SITE_URL` برابط موقعك الفعلي:

```bash
curl -F "url=https://YOUR_SITE_URL.netlify.app/api/telegram" \
  https://api.telegram.org/bot8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU/setWebhook
```

---

## 🎯 روابط المشروع بعد النشر:

### لوحة التحكم:
```
https://YOUR_SITE_URL.netlify.app/dashboard
```

### جميع الصفحات:
- **الرئيسية:** `https://YOUR_SITE_URL.netlify.app/`
- **الخدمات:** `https://YOUR_SITE_URL.netlify.app/services`
- **الطلبات:** `https://YOUR_SITE_URL.netlify.app/orders`
- **المستخدمين:** `https://YOUR_SITE_URL.netlify.app/users`
- **الإعدادات:** `https://YOUR_SITE_URL.netlify.app/settings`

### API Endpoints:
- **الخدمات:** `https://YOUR_SITE_URL.netlify.app/api/services`
- **الطلبات:** `https://YOUR_SITE_URL.netlify.app/api/orders`
- **المستخدمين:** `https://YOUR_SITE_URL.netlify.app/api/users`
- **الإحصائيات:** `https://YOUR_SITE_URL.netlify.app/api/stats`
- **مزامنة الخدمات:** `https://YOUR_SITE_URL.netlify.app/api/sync-services`
- **رصيد SMM:** `https://YOUR_SITE_URL.netlify.app/api/smm-balance`

---

## 📊 الميزات الكاملة:

### للعملاء (من تيليجرام):
1. ✅ طلب خدمات من البوت
2. ✅ تتبع الطلبات
3. ✅ معرفة الرصيد
4. ✅ دعم فني

### للمسؤول (من لوحة التحكم):
1. ✅ مزامنة الخدمات من SMM
2. ✅ إدارة الطلبات
3. ✅ شحن أرصدة المستخدمين
4. ✅ تعديل هامش الربح
5. ✅ إحصائيات شاملة
6. ✅ إدارة المستخدمين

---

## 🎉 مبروك! البوت جاهز للاستخدام!

### الخطوات التالية:

1. **انشر المشروع على Netlify**
2. **أضف متغيرات البيئة**
3. **أعد تعيين Webhook للبوت**
4. **ابدأ استقبال الطلبات!**

---

## 📞 الدعم الفني:

### إذا واجهت مشاكل:

1. **تحقق من السجلات:**
   - اذهب إلى Netlify Dashboard
   - اختر موقعك
   - اضغط "Functions" → "View logs"

2. **تأكد من متغيرات البيئة:**
   - Site settings → Environment variables
   - تأكد من إضافة جميع المتغيرات

3. **أعد النشر:**
   - اضغط "Deploys" → "Trigger deploy" → "Deploy site"

4. **تحقق من Webhook:**
   ```bash
   curl https://api.telegram.org/bot8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU/getWebhookInfo
   ```

---

## 📝 التكنولوجيا المستخدمة:

- **Frontend:** React 19 + TypeScript + Vite
- **Styling:** Tailwind CSS 4
- **Animations:** Framer Motion
- **Routing:** React Router DOM
- **Database:** Supabase (PostgreSQL)
- **API:** Vercel Serverless Functions / Netlify Functions
- **Bot:** Telegram Bot API
- **SMM Provider:** SMM Sharks API

---

## 🎯 النتائج المتوقعة:

### مع هذا النظام يمكنك:

1. **توفير الوقت:**
   - مزامنة تلقائية للخدمات
   - تنفيذ سريع للطلبات
   - تتبع آلي للحالة

2. **زيادة الأرباح:**
   - هامش ربح قابل للتعديل (20% افتراضي)
   - أسعار منافسة من SMM Sharks
   - ربح مضمون على كل طلب

3. **سهولة الإدارة:**
   - لوحة تحكم واضحة
   - إدارة شاملة للمستخدمين
   - تقارير وإحصائيات

---

## ✅ الخلاصة:

**المشروع جاهز 100% للنشر على Netlify!**

- ✅ بوت تيليجرام متكامل
- ✅ لوحة تحكم احترافية
- ✅ ربط مع SMM Sharks
- ✅ قاعدة بيانات Supabase
- ✅ مزامنة الخدمات التلقائية
- ✅ تنفيذ الطلبات التلقائي
- ✅ نظام شحن الأرصدة
- ✅ إحصائيات شاملة
- ✅ إدارة المستخدمين
- ✅ تعديل هامش الربح

**ابدأ الآن واستمتع بالأرباح! 💎**
