# 🤖 MadmoonStore Bot - بوت تيليجرام لخدمات SMM

بوت تيليجرام متكامل لبيع خدمات زيادة المتابعين والتفاعل مع لوحة تحكم احترافية.

## ✨ المميزات

- 🤖 بوت تيليجرام متكامل مع قائمة تفاعلية
- 🎨 موقع ويب احترافي بتصميم عصري
- 📊 لوحة تحكم متقدمة لإدارة كل شيء
- 🔗 ربط تلقائي مع مزود SMM (SMM Sharks)
- 💰 نظام إدارة الأرصدة
- 📦 مزامنة تلقائية للخدمات
- 🚀 تنفيذ تلقائي للطلبات
- 📱 متجاوب مع جميع الأجهزة

## 🚀 التثبيت السريع

### الطريقة الأولى: Netlify Drop (الأسهل) ⭐

1. **تحميل الملف:**
   - حمل `madmoonstore-lite.tar.gz`

2. **فك الضغط:**
   - استخرج الملفات على جهازك

3. **الرفع:**
   - اذهب إلى https://app.netlify.com/drop
   - اسحب المجلد وأفلته
   - انتظر النشر

4. **إضافة المتغيرات:**
   - اذهب إلى Site settings → Environment variables
   - أضف المتغيرات من قسم "المتغيرات المطلوبة" أدناه

5. **إعداد Webhook:**
   ```bash
   curl -F "url=https://YOUR_SITE_URL.netlify.app/api/telegram" \
     https://api.telegram.org/bot8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU/setWebhook
   ```

### الطريقة الثانية: GitHub + Netlify

1. أنشئ مستودع جديد على GitHub
2. ارفع الملفات
3. اربط المستودع مع Netlify
4. أضف متغيرات البيئة
5. انشر!

## 🔑 المتغيرات المطلوبة

```
TELEGRAM_BOT_TOKEN = 8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU
SMM_API_URL = https://smmsharks.com/api/v2
SMM_API_KEY = 01b815347b66b2fe9527d631b98bbb3a
NEXT_PUBLIC_SUPABASE_URL = https://zdjzdgxwhtjedknrzxmx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY = sb_publishable_VGUQhIqd0T6kN-PVN8I1gw_W7ZYO3-B
SUPABASE_SERVICE_ROLE_KEY = sb_secret_Yg6OV3hl7Ie1fYN0xuebcQ_nIsnBu4p
VITE_SUPABASE_URL = https://zdjzdgxwhtjedknrzxmx.supabase.co
VITE_SUPABASE_ANON_KEY = sb_publishable_VGUQhIqd0T6kN-PVN8I1gw_W7ZYO3-B
```

## 📁 هيكل المشروع

```
madmoonstore-bot/
├── src/                  # ملفات React
│   ├── pages/           # الصفحات
│   ├── components/      # المكونات
│   └── lib/            # المكتبات
├── api/                 # ملفات API
│   ├── telegram.js      # بوت تيليجرام
│   ├── services.js      # إدارة الخدمات
│   ├── orders.js        # إدارة الطلبات
│   ├── users.js         # إدارة المستخدمين
│   └── smm.js          # ربط SMM
├── public/              # الملفات العامة
├── package.json         # تبعيات المشروع
└── netlify.toml         # إعدادات Netlify
```

## 🎯 الاستخدام

### للعملاء (من البوت):

1. افتح @MadmoonStore_bot
2. اكتب `/start`
3. اختر الخدمة المطلوبة
4. أدخل الرابط والكمية
5. تأكيد الطلب

### للمسؤول (من الموقع):

1. افتح لوحة التحكم: `/dashboard`
2. مزامنة الخدمات من SMM
3. شحن أرصدة للمستخدمين
4. راقب الطلبات
5. تحديث الحالات

## 📊 لوحة التحكم

### الصفحات المتاحة:

- **الرئيسية:** `/` - صفحة ترحيبية
- **لوحة التحكم:** `/dashboard` - إحصائيات شاملة
- **الخدمات:** `/services` - إدارة الخدمات
- **الطلبات:** `/orders` - تتبع الطلبات
- **المستخدمين:** `/users` - إدارة المستخدمين
- **الإعدادات:** `/settings` - تكوين النظام

## 🔧 الأوامر

### بناء المشروع:
```bash
npm install
npm run build
```

### التشغيل المحلي:
```bash
npm run dev
```

### النشر على Netlify:
```bash
npm install -g netlify-cli
netlify login
netlify deploy --prod
```

## 📱 البوت

### الأوامر المتاحة:

- `/start` - البدء وعرض القائمة الرئيسية
- `/help` - عرض التعليمات

### القوائم التفاعلية:

- 🛒 طلب خدمة
- 📊 طلباتي
- 💰 رصيدي
- 📞 دعم فني

## 💰 الربح مع البوت

### 1. ضبط هامش الربح:
- اذهب إلى `/settings`
- عدّل هامش الربح (مثلاً 20%)
- مزامنة الخدمات لتحديث الأسعار

### 2. شحن أرصدة:
- اشحن رصيدك في SMM Sharks
- شحن أرصدة للعملاء

### 3. التسويق:
- شارك رابط البوت: @MadmoonStore_bot
- شارك رابط الموقع
- ابدأ في كسب الأرباح!

## 🛠️ التقنيات المستخدمة

- **Frontend:** React 19, TypeScript, Tailwind CSS 4
- **Backend:** Node.js, Netlify Functions
- **Database:** Supabase (PostgreSQL)
- **SMM Provider:** SMM Sharks API
- **Bot:** Telegram Bot API
- **Hosting:** Netlify

## 📞 الدعم

إذا واجهت أي مشكلة:

1. تحقق من متغيرات البيئة
2. راجع سجلات Netlify
3. تأكد من Webhook
4. اختبر API يدوياً

## 📄 الترخيص

هذا المشروع مفتوح المصدر ومتاح للاستخدام التجاري.

## 🎉 مبروك!

الآن لديك بوت تيليجرام احترافي جاهز للعمل!

ابدأ في كسب الأرباح الآن! 💰
