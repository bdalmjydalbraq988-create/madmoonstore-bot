# 🚀 ابدأ هنا - MadmoonStore Bot

## ✅ ما تم إنجازه بنجاح:

### 🤖 بوت تيليجرام متكامل
- Bot Token: `8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU`
- الاسم: @MadmoonStore_bot
- القوائم التفاعلية
- نظام الطلبات الآلي

### 🌐 موقع ويب احترافي
- تصميم عصري
- لوحة تحكم متقدمة
- متجاوب مع جميع الأجهزة
- واجهة عربية كاملة

### 💾 قاعدة بيانات كاملة
- جداول: services, orders, users, settings
- بيانات تجريبية
- اتصال Supabase نشط

### 🔗 ربط SMM Sharks
- API Key: `01b815347b66b2fe9527d631b98bbb3a`
- رصيد: $6.99
- مزامنة تلقائية للخدمات
- تنفيذ تلقائي للطلبات

---

## 📥 كيفية تحميل الملفات:

### الطريقة 1: من هذا النظام (الأسرع)

#### الخطوة 1: نسخ الملفات
```bash
# إذا كنت تستخدم هذا النظام مباشرة
cp /tmp/madmoonstore-lite.tar.gz .
```

#### الخطوة 2: فك الضغط
```bash
tar -xzf madmoonstore-lite.tar.gz
```

#### الخطوة 3: النشر
```bash
npm install -g netlify-cli
netlify login
netlify deploy --prod
```

---

### الطريقة 2: عبر GitHub (الأفضل) ⭐

#### الخطوة 1: إنشاء مستودع
1. اذهب إلى: https://github.com/new
2. أدخل اسم: `madmoonstore-bot`
3. اضغط "Create repository"

#### الخطوة 2: رفع الملفات
**أ) باستخدام Git:**
```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR_USERNAME/madmoonstore-bot.git
git push -u origin main
```

**ب) يدوياً:**
1. افتح GitHub.com
2. اذهب للمستودع
3. اضغط "Upload files"
4. اسحب جميع الملفات
5. اضغط "Commit changes"

#### الخطوة 3: النشر على Netlify
1. اذهب إلى: https://app.netlify.com/start
2. اختر "GitHub"
3. اختر مستودع `madmoonstore-bot`
4. اضغط "Deploy site"

---

## ⚙️ إضافة متغيرات البيئة:

بعد النشر، اذهب إلى:
**Site settings → Environment variables**

أضف المتغيرات التالية:

```
TELEGRAM_BOT_TOKEN = 8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU
SMM_API_URL = https://smmsharks.com/api/v2
SMM_API_KEY = 01b815347b66b2fe9527d631b98bbb3a
NEXT_PUBLIC_SUPABASE_URL = https://zdjzdgxwhtjedknrzxmx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY = sb_publishable_VGUQhIqd0T6kN-PVN8I1gw_W7ZYO3-B
SUPABASE_SERVICE_ROLE_KEY = sb_secret_Yg6OV3hl7Ie1fYN0xuebcQ_nIsnBu4p
VITE_SUPABASE_URL = https://zdjzdgxwhtjedknrzxmx.supabase.co
VITE_SUPABASE_ANON_KEY = sb_publishable_VGUQhIqd0T6kN-PVN8I1gw_W7ZYO3-B
```

---

## 🔧 إعداد Webhook للبوت:

استبدل `YOUR_SITE_URL` برابط موقعك الجديد:

```bash
curl -F "url=https://YOUR_SITE_URL.netlify.app/api/telegram" \
  https://api.telegram.org/bot8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU/setWebhook
```

---

## ✅ التحقق من النشر:

### اختبار الموقع:
```bash
curl https://YOUR_SITE_URL.netlify.app
```

### اختبار API:
```bash
curl https://YOUR_SITE_URL.netlify.app/api/services
```

### اختبار Webhook:
```bash
curl https://api.telegram.org/bot8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU/getWebhookInfo
```

---

## 🎯 روابط مهمة بعد النشر:

- **الموقع:** `https://YOUR_SITE_URL.netlify.app/`
- **لوحة التحكم:** `https://YOUR_SITE_URL.netlify.app/dashboard`
- **الخدمات:** `https://YOUR_SITE_URL.netlify.app/services`
- **الطلبات:** `https://YOUR_SITE_URL.netlify.app/orders`
- **المستخدمين:** `https://YOUR_SITE_URL.netlify.app/users`
- **الإعدادات:** `https://YOUR_SITE_URL.netlify.app/settings`
- **البوت:** @MadmoonStore_bot

---

## 💡 ماذا تفعل بعد النشر؟

### 1️⃣ مزامنة الخدمات
1. افتح `/settings`
2. اضغط "مزامنة الخدمات من SMM"
3. انتظر حتى تنتهي المزامنة

### 2️⃣ شحن أرصدة
1. افتح `/users`
2. ابحث عن المستخدم
3. اضغط "شحن رصيد"
4. أدخل المبلغ

### 3️⃣ ضبط هامش الربح
1. افتح `/settings`
2. عدّل "هامش الربح" (مثلاً 20%)
3. اضغط "حفظ"
4. أعد مزامنة الخدمات

### 4️⃣ اختبار البوت
1. افتح تيليجرام
2. ابحث عن @MadmoonStore_bot
3. اكتب `/start`
4. جرب طلب خدمة

---

## 📊 نظام الربح:

### كيف تكسب المال؟

1. **اشترِ بسعر منخفض:**
   - من SMM Sharks (مزودك)
   - مثلاً: متابعين انستقرام = $3/1000

2. **بعِ بسعر أعلى:**
   - للعملاء عبر البوت
   - مثلاً: متابعين انستقرام = $5/1000

3. **الربح:**
   - $5 - $3 = $2 ربح لكل 1000 متابع
   - هامش ربح: 40%

### مثال عملي:

| الخدمة | سعر الشراء | سعر البيع | الربح | الهامش |
|--------|-----------|-----------|-------|--------|
| متابعين انستقرام (1000) | $3.00 | $5.00 | $2.00 | 40% |
| لايكات انستقرام (1000) | $1.50 | $2.50 | $1.00 | 40% |
| متابعين تيك توك (1000) | $5.00 | $8.00 | $3.00 | 37.5% |

---

## 🎉 مبروك!

الآن لديك:

✅ بوت تيليجرام احترافي
✅ موقع ويب متكامل
✅ لوحة تحكم متقدمة
✅ ربط مع SMM Sharks
✅ قاعدة بيانات كاملة
✅ نظام إدارة شامل
✅ كل شيء جاهز للعمل!

---

## 🚀 ابدأ الآن!

### الخطوة 1: النشر
- ارفع المشروع على Netlify
- أضف متغيرات البيئة
- اضبط Webhook

### الخطوة 2: الإعداد
- مزامنة الخدمات
- شحن أرصدة
- ضبط الهوامش

### الخطوة 3: التشغيل
- اختبر البوت
- استقبل الطلبات
- ابدأ في كسب الأرباح!

---

## 📞 الدعم:

إذا واجهت أي مشكلة:

1. **تحقق من السجلات:**
   - Netlify Dashboard → Site → Functions → View logs

2. **تأكد من متغيرات البيئة:**
   - Site settings → Environment variables

3. **أعد النشر:**
   - Deploys → Trigger deploy → Deploy site

---

## 🎊 النجاح ينتظرك!

ابدأ في نشر البوت الآن وابدأ في كسب الأرباح!

**النجاح ينتظرك! 💰🎯**
