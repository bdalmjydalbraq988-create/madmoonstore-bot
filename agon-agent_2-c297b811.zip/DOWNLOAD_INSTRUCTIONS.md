# 📥 تعليمات تحميل ملفات المشروع

## 📍 أين توجد الملفات؟

الملفات المضغوطة موجودة في:
```
/tmp/madmoonstore-lite.tar.gz (28MB) - أنصح به
/tmp/madmoonstore-full.tar.gz (56MB) - كامل مع node_modules
```

## 🚀 طريقة التحميل والنشر:

### الطريقة 1: إذا كنت تستخدم هذا النظام مباشرة

#### الخطوة 1: نسخ الملفات
```bash
# نسخ الملف إلى المجلد الحالي
cp /tmp/madmoonstore-lite.tar.gz .

# فك الضغط
tar -xzf madmoonstore-lite.tar.gz

# الدخول إلى المجلد
cd madmoonstore-bot

# التثبيت
npm install

# البناء
npm run build
```

#### الخطوة 2: النشر على Netlify
```bash
# تثبيت Netlify CLI
npm install -g netlify-cli

# تسجيل الدخول
netlify login

# النشر
netlify deploy --prod
```

---

### الطريقة 2: إذا كنت تريد تحميل الملفات يدوياً

#### الخطوة 1: تحميل الملف
الملفات موجودة في المسار:
```
/tmp/madmoonstore-lite.tar.gz
```

#### الخطوة 2: فك الضغط
- على Linux/Mac:
  ```bash
  tar -xzf madmoonstore-lite.tar.gz
  ```

- على Windows:
  - استخدم برنامج مثل WinRAR أو 7-Zip
  - انقر بزر الماوس الأيمن على الملف
  - اختر "Extract Here"

#### الخطوة 3: الرفع على Netlify
1. افتح: https://app.netlify.com/drop
2. اسحب المجلد المستخرج
3. انتظر النشر
4. انسخ الرابط

#### الخطوة 4: إضافة المتغيرات
اذهب إلى: Site settings → Environment variables

أضف:
```
TELEGRAM_BOT_TOKEN = 8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU
SMM_API_URL = https://smmsharks.com/api/v2
SMM_API_KEY = 01b815347b66b2fe9527d631b98bbb3a
NEXT_PUBLIC_SUPABASE_URL = https://zdjzdgxwhtjedknrzxmx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY = sb_publishable_VGUQhIqd0T6kN-PVN8I1gw_W7ZYO3-B
SUPABASE_SERVICE_ROLE_KEY = sb_secret_Yg6OV3hl7Ie1fYN0xuebcQ_nIsnBu4p
VITE_SUPABASE_URL = https://zdjzdgxwhtjedknrzxmx.supabase.co
VITE_SUPABASE_ANON_KEY = sb_publishable_VGUQhIqd0T6kN-PVN8I1gw_W7ZYO3-B
```

#### الخطوة 5: إعداد Webhook
استبدل `YOUR_SITE_URL` برابط موقعك:

```bash
curl -F "url=https://YOUR_SITE_URL.netlify.app/api/telegram" \
  https://api.telegram.org/bot8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU/setWebhook
```

---

### الطريقة 3: استخدام GitHub (الأفضل) ⭐

#### الخطوة 1: إنشاء مستودع GitHub
1. اذهب إلى: https://github.com/new
2. أدخل اسم: `madmoonstore-bot`
3. اضغط "Create repository"

#### الخطوة 2: رفع الملفات
**أ) باستخدام Git:**
```bash
# من المجلد الحالي
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR_USERNAME/madmoonstore-bot.git
git push -u origin main
```

**ب) يدوياً عبر GitHub:**
1. افتح GitHub.com
2. اذهب للمستودع
3. اضغط "Upload files"
4. اسحب جميع الملفات
5. اضغط "Commit changes"

#### الخطوة 3: النشر على Netlify
1. اذهب إلى: https://app.netlify.com/start
2. اختر "GitHub"
3. اختر مستودع `madmoonstore-bot`
4. اضغط "Deploy site"

#### الخطوة 4: إضافة المتغيرات
نفس الخطوات المذكورة أعلاه

---

## ✅ التحقق من النشر:

### اختبار الموقع:
```bash
curl https://YOUR_SITE_URL.netlify.app
```

### اختبار API:
```bash
curl https://YOUR_SITE_URL.netlify.app/api/services
```

### اختبار Webhook:
```bash
curl https://api.telegram.org/bot8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU/getWebhookInfo
```

---

## 🎯 بعد النشر:

### 1. افتح الموقع
```
https://YOUR_SITE_URL.netlify.app
```

### 2. افتح البوت
```
@MadmoonStore_bot
```

### 3. ابدأ!
اكتب `/start` في البوت

---

## 📞 إذا واجهت مشاكل:

### المشكلة: الملفات غير موجودة
**الحل:**
- الملفات موجودة في `/tmp/`
- يمكنك نسخها من هناك
- أو استخدام GitHub للنشر

### المشكلة: فشل النشر
**الحل:**
1. تأكد من وجود `package.json`
2. تحقق من جميع الملفات
3. راجع سجلات Netlify

### المشكلة: البوت لا يعمل
**الحل:**
1. تحقق من `TELEGRAM_BOT_TOKEN`
2. تأكد من Webhook
3. راجع سجلات Functions

---

## 🎉 مبروك!

الآن لديك كل ما تحتاجه لنشر البوت!

ابدأ في كسب الأرباح! 💰
