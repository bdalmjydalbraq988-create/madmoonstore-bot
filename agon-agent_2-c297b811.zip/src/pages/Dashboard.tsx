import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Users, ShoppingBag, DollarSign, Activity, ArrowUpRight, Clock, CheckCircle, XCircle, Loader2 } from 'lucide-react';

interface Stats {
  usersCount: number;
  ordersCount: number;
  totalRevenue: number;
  statusCounts: {
    pending: number;
    processing: number;
    completed: number;
    cancelled: number;
  };
  recentOrders: any[];
}

export default function Dashboard() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      const res = await fetch('/api/stats');
      const data = await res.json();
      setStats(data);
    } catch (err) {
      console.error('Error fetching stats:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-12 h-12 text-purple-500 animate-spin" />
      </div>
    );
  }

  const statCards = [
    {
      title: 'المستخدمين',
      value: stats?.usersCount || 0,
      icon: <Users className="w-6 h-6" />,
      color: 'from-blue-500 to-blue-600',
      change: '+12%'
    },
    {
      title: 'الطلبات',
      value: stats?.ordersCount || 0,
      icon: <ShoppingBag className="w-6 h-6" />,
      color: 'from-purple-500 to-purple-600',
      change: '+8%'
    },
    {
      title: 'الإيرادات',
      value: `$${(stats?.totalRevenue || 0).toFixed(2)}`,
      icon: <DollarSign className="w-6 h-6" />,
      color: 'from-green-500 to-green-600',
      change: '+23%'
    },
    {
      title: 'قيد التنفيذ',
      value: (stats?.statusCounts?.processing || 0) + (stats?.statusCounts?.pending || 0),
      icon: <Activity className="w-6 h-6" />,
      color: 'from-orange-500 to-orange-600',
      change: 'نشط'
    }
  ];

  const getStatusBadge = (status: string) => {
    const badges = {
      pending: { bg: 'bg-yellow-500/20', text: 'text-yellow-400', icon: <Clock className="w-4 h-4" /> },
      processing: { bg: 'bg-blue-500/20', text: 'text-blue-400', icon: <Loader2 className="w-4 h-4 animate-spin" /> },
      completed: { bg: 'bg-green-500/20', text: 'text-green-400', icon: <CheckCircle className="w-4 h-4" /> },
      cancelled: { bg: 'bg-red-500/20', text: 'text-red-400', icon: <XCircle className="w-4 h-4" /> }
    };
    return badges[status as keyof typeof badges] || badges.pending;
  };

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl font-bold text-white mb-2">لوحة التحكم</h1>
          <p className="text-gray-400">نظرة عامة على أداء المنصة</p>
        </motion.div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {statCards.map((stat, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6"
            >
              <div className="flex items-center justify-between mb-4">
                <div className={`w-12 h-12 bg-gradient-to-br ${stat.color} rounded-xl flex items-center justify-center`}>
                  <div className="text-white">{stat.icon}</div>
                </div>
                <span className="text-green-400 text-sm font-medium flex items-center gap-1">
                  <ArrowUpRight className="w-4 h-4" />
                  {stat.change}
                </span>
              </div>
              <h3 className="text-2xl font-bold text-white mb-1">{stat.value}</h3>
              <p className="text-gray-400 text-sm">{stat.title}</p>
            </motion.div>
          ))}
        </div>

        {/* Recent Orders */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6"
        >
          <h2 className="text-xl font-bold text-white mb-6">آخر الطلبات</h2>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="text-gray-400 text-sm border-b border-white/10">
                  <th className="text-right pb-4 font-medium">الخدمة</th>
                  <th className="text-right pb-4 font-medium">الكمية</th>
                  <th className="text-right pb-4 font-medium">السعر</th>
                  <th className="text-right pb-4 font-medium">الحالة</th>
                  <th className="text-right pb-4 font-medium">التاريخ</th>
                </tr>
              </thead>
              <tbody>
                {stats?.recentOrders?.map((order, i) => {
                  const badge = getStatusBadge(order.status);
                  return (
                    <tr key={i} className="border-b border-white/5">
                      <td className="py-4 text-white">{order.service_name}</td>
                      <td className="py-4 text-gray-300">{order.quantity?.toLocaleString()}</td>
                      <td className="py-4 text-gray-300">${order.total_price?.toFixed(2)}</td>
                      <td className="py-4">
                        <span className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-sm ${badge.bg} ${badge.text}`}>
                          {badge.icon}
                          {order.status}
                        </span>
                      </td>
                      <td className="py-4 text-gray-400 text-sm">
                        {new Date(order.created_at).toLocaleDateString('ar-EG')}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </motion.div>
      </div>
    </div>
  );
}