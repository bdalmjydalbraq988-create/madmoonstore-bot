import { motion } from 'framer-motion';
import { Bot, Zap, Shield, TrendingUp, Users, Star } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Home() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 px-4">
        <div className="absolute inset-0 bg-gradient-to-r from-purple-500/20 to-pink-500/20 blur-3xl" />
        <div className="relative max-w-7xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center gap-2 bg-purple-500/20 backdrop-blur-sm px-4 py-2 rounded-full mb-6">
              <Bot className="w-5 h-5 text-purple-400" />
              <span className="text-purple-300 text-sm font-medium">بوت تيليجرام احترافي</span>
            </div>
            <h1 className="text-5xl md:text-7xl font-bold text-white mb-6">
              بوت الرشق
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400">
                {' '}السريع
              </span>
            </h1>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto mb-8">
              منصة متكاملة لزيادة المتابعين والتفاعل على جميع منصات التواصل الاجتماعي
              مع بوت تيليجرام ذكي ولوحة تحكم احترافية
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                to="/dashboard"
                className="px-8 py-4 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-semibold rounded-xl hover:from-purple-700 hover:to-pink-700 transition-all shadow-lg shadow-purple-500/30"
              >
                🚀 ابدأ الآن
              </Link>
              <a
                href="https://t.me/your_bot"
                target="_blank"
                rel="noopener noreferrer"
                className="px-8 py-4 bg-white/10 backdrop-blur-sm text-white font-semibold rounded-xl hover:bg-white/20 transition-all border border-white/20"
              >
                🤖 تيليجرام
              </a>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <motion.h2
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            className="text-4xl font-bold text-white text-center mb-16"
          >
            ✨ مميزات البوت
          </motion.h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: <Zap className="w-8 h-8" />,
                title: 'سرعة فائقة',
                description: 'تنفيذ الطلبات خلال دقائق مع نظام آلي متطور'
              },
              {
                icon: <Shield className="w-8 h-8" />,
                title: 'آمن وموثوق',
                description: 'حماية كاملة لحسابك مع ضمان الجودة'
              },
              {
                icon: <TrendingUp className="w-8 h-8" />,
                title: 'أسعار منافسة',
                description: 'أفضل الأسعار في السمع مع جودة عالية'
              },
              {
                icon: <Users className="w-8 h-8" />,
                title: 'دعم فني 24/7',
                description: 'فريق دعم متاح على مدار الساعة'
              },
              {
                icon: <Star className="w-8 h-8" />,
                title: 'جودة عالية',
                description: 'متابعين حقيقيين وتفاعل طبيعي'
              },
              {
                icon: <Bot className="w-8 h-8" />,
                title: 'بوت ذكي',
                description: 'بوت تيليgram متكامل مع واجهة سهلة'
              }
            ].map((feature, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-all"
              >
                <div className="w-14 h-14 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center mb-4">
                  <div className="text-white">{feature.icon}</div>
                </div>
                <h3 className="text-xl font-bold text-white mb-2">{feature.title}</h3>
                <p className="text-gray-400">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Platforms */}
      <section className="py-20 px-4 bg-black/20">
        <div className="max-w-7xl mx-auto text-center">
          <h2 className="text-4xl font-bold text-white mb-12">المنصات المدعومة</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
            {[
              { name: 'Instagram', color: 'from-pink-500 to-purple-500' },
              { name: 'Twitter', color: 'from-blue-400 to-blue-600' },
              { name: 'TikTok', color: 'from-gray-800 to-pink-500' },
              { name: 'YouTube', color: 'from-red-500 to-red-700' },
              { name: 'Facebook', color: 'from-blue-500 to-blue-700' },
              { name: 'Telegram', color: 'from-blue-400 to-cyan-500' }
            ].map((platform, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ delay: i * 0.1 }}
                className={`bg-gradient-to-br ${platform.color} rounded-2xl p-6 text-white font-bold text-lg`}
              >
                {platform.name}
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="bg-gradient-to-r from-purple-600/20 to-pink-600/20 backdrop-blur-sm border border-purple-500/30 rounded-3xl p-12"
          >
            <h2 className="text-4xl font-bold text-white mb-4">
              جاهز للبدء؟
            </h2>
            <p className="text-gray-300 mb-8">
              انضم إلى آلاف العملاء الراضين وابدأ بزيادة متابعيك الآن
            </p>
            <Link
              to="/dashboard"
              className="inline-block px-10 py-4 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-semibold rounded-xl hover:from-purple-700 hover:to-pink-700 transition-all shadow-lg shadow-purple-500/30"
            >
              🚀 ابدأ مجاناً
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  );
}