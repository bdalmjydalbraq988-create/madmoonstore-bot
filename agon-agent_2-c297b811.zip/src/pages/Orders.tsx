import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Search, Filter, CheckCircle, Clock, XCircle, Loader2, Eye, Zap, RefreshCw } from 'lucide-react';

interface Order {
  id: number;
  service_name: string;
  telegram_username: string;
  link: string;
  quantity: number;
  completed_quantity: number;
  total_price: number;
  status: 'pending' | 'processing' | 'completed' | 'cancelled';
  created_at: string;
}

export default function Orders() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    try {
      const res = await fetch('/api/orders');
      const data = await res.json();
      setOrders(data);
    } catch (err) {
      console.error('Error fetching orders:', err);
    } finally {
      setLoading(false);
    }
  };

  const updateOrderStatus = async (id: number, status: string, completedQuantity?: number) => {
    try {
      await fetch('/api/orders', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, status, completed_quantity: completedQuantity })
      });
      fetchOrders();
    } catch (err) {
      console.error('Error updating order:', err);
    }
  };

  const dispatchOrder = async (orderId: number) => {
    try {
      const res = await fetch('/api/dispatch-order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ orderId })
      });
      const data = await res.json();
      if (data.success) {
        alert('تم إرسال الطلب إلى مزود SMM بنجاح!');
        fetchOrders();
      } else {
        alert('خطأ: ' + data.error);
      }
    } catch (err) {
      console.error('Dispatch error:', err);
      alert('حدث خطأ أثناء إرسال الطلب');
    }
  };

  const checkOrderStatus = async (orderId: number) => {
    try {
      const res = await fetch('/api/check-status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ orderId })
      });
      const data = await res.json();
      if (data.success) {
        alert(`تم تحديث الحالة: ${data.status}`);
        fetchOrders();
      } else {
        alert('خطأ: ' + data.error);
      }
    } catch (err) {
      console.error('Check status error:', err);
      alert('حدث خطأ أثناء التحقق من الحالة');
    }
  };

  const filteredOrders = orders.filter(order => {
    const matchesSearch = 
      order.service_name.toLowerCase().includes(search.toLowerCase()) ||
      order.telegram_username?.toLowerCase().includes(search.toLowerCase());
    const matchesFilter = filter === 'all' || order.status === filter;
    return matchesSearch && matchesFilter;
  });

  const getStatusBadge = (status: string) => {
    const badges = {
      pending: { bg: 'bg-yellow-500/20', text: 'text-yellow-400', icon: <Clock className="w-4 h-4" />, label: 'قيد الانتظار' },
      processing: { bg: 'bg-blue-500/20', text: 'text-blue-400', icon: <Loader2 className="w-4 h-4 animate-spin" />, label: 'قيد التنفيذ' },
      completed: { bg: 'bg-green-500/20', text: 'text-green-400', icon: <CheckCircle className="w-4 h-4" />, label: 'مكتمل' },
      cancelled: { bg: 'bg-red-500/20', text: 'text-red-400', icon: <XCircle className="w-4 h-4" />, label: 'ملغي' }
    };
    return badges[status as keyof typeof badges] || badges.pending;
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-12 h-12 text-purple-500 animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl font-bold text-white mb-2">الطلبات</h1>
          <p className="text-gray-400">إدارة وتتبع جميع الطلبات</p>
        </motion.div>

        {/* Search & Filter */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="flex-1 relative">
            <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="بحث عن طلب..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pr-12 pl-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-purple-500"
            />
          </div>
          <div className="flex gap-2 flex-wrap">
            {['all', 'pending', 'processing', 'completed', 'cancelled'].map(status => (
              <button
                key={status}
                onClick={() => setFilter(status)}
                className={`px-4 py-2 rounded-lg font-medium transition-all ${
                  filter === status
                    ? 'bg-purple-600 text-white'
                    : 'bg-white/5 text-gray-400 hover:bg-white/10'
                }`}
              >
                {status === 'all' ? 'الكل' : getStatusBadge(status).label}
              </button>
            ))}
          </div>
        </div>

        {/* Orders Table */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl overflow-hidden"
        >
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="text-gray-400 text-sm border-b border-white/10">
                  <th className="text-right py-4 px-6 font-medium">ID</th>
                  <th className="text-right py-4 px-6 font-medium">الخدمة</th>
                  <th className="text-right py-4 px-6 font-medium">المستخدم</th>
                  <th className="text-right py-4 px-6 font-medium">الرابط</th>
                  <th className="text-right py-4 px-6 font-medium">الكمية</th>
                  <th className="text-right py-4 px-6 font-medium">السعر</th>
                  <th className="text-right py-4 px-6 font-medium">الحالة</th>
                  <th className="text-right py-4 px-6 font-medium">التاريخ</th>
                  <th className="text-right py-4 px-6 font-medium">إجراءات</th>
                </tr>
              </thead>
              <tbody>
                {filteredOrders.map((order, i) => {
                  const badge = getStatusBadge(order.status);
                  return (
                    <tr
                      key={order.id}
                      className="border-b border-white/5 hover:bg-white/5 transition-colors"
                    >
                      <td className="py-4 px-6 text-white font-mono">#{order.id}</td>
                      <td className="py-4 px-6 text-white">{order.service_name}</td>
                      <td className="py-4 px-6 text-gray-300">@{order.telegram_username || 'N/A'}</td>
                      <td className="py-4 px-6">
                        <a
                          href={order.link}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-purple-400 hover:text-purple-300 text-sm truncate block max-w-[200px]"
                        >
                          {order.link}
                        </a>
                      </td>
                      <td className="py-4 px-6 text-gray-300">
                        {order.completed_quantity || 0} / {order.quantity}
                      </td>
                      <td className="py-4 px-6 text-gray-300">${order.total_price?.toFixed(2)}</td>
                      <td className="py-4 px-6">
                        <span className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-sm ${badge.bg} ${badge.text}`}>
                          {badge.icon}
                          {badge.label}
                        </span>
                      </td>
                      <td className="py-4 px-6 text-gray-400 text-sm">
                        {new Date(order.created_at).toLocaleDateString('ar-EG')}
                      </td>
                      <td className="py-4 px-6">
                        <div className="flex gap-2 flex-wrap">
                          <button
                            onClick={() => setSelectedOrder(order)}
                            className="p-2 text-gray-400 hover:text-white transition-colors"
                            title="عرض التفاصيل"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          {order.status === 'pending' && (
                            <button
                              onClick={() => dispatchOrder(order.id)}
                              className="p-2 text-purple-400 hover:text-purple-300 transition-colors"
                              title="إرسال إلى SMM"
                            >
                              <Zap className="w-4 h-4" />
                            </button>
                          )}
                          {order.status === 'processing' && (
                            <button
                              onClick={() => checkOrderStatus(order.id)}
                              className="p-2 text-cyan-400 hover:text-cyan-300 transition-colors"
                              title="تحديث الحالة من SMM"
                            >
                              <RefreshCw className="w-4 h-4" />
                            </button>
                          )}
                          {order.status === 'pending' && (
                            <button
                              onClick={() => updateOrderStatus(order.id, 'processing')}
                              className="p-2 text-blue-400 hover:text-blue-300 transition-colors"
                              title="بدء التنفيذ يدوياً"
                            >
                              <Loader2 className="w-4 h-4" />
                            </button>
                          )}
                          {order.status === 'processing' && (
                            <button
                              onClick={() => updateOrderStatus(order.id, 'completed', order.quantity)}
                              className="p-2 text-green-400 hover:text-green-300 transition-colors"
                              title="إكمال يدوياً"
                            >
                              <CheckCircle className="w-4 h-4" />
                            </button>
                          )}
                          {(order.status === 'pending' || order.status === 'processing') && (
                            <button
                              onClick={() => updateOrderStatus(order.id, 'cancelled')}
                              className="p-2 text-red-400 hover:text-red-300 transition-colors"
                              title="إلغاء"
                            >
                              <XCircle className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </motion.div>

        {/* Order Details Modal */}
        {selectedOrder && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-slate-900 border border-white/10 rounded-2xl p-6 w-full max-w-lg"
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-white">تفاصيل الطلب #{selectedOrder.id}</h2>
                <button
                  onClick={() => setSelectedOrder(null)}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  ✕
                </button>
              </div>
              <div className="space-y-4">
                <div className="bg-white/5 rounded-xl p-4">
                  <p className="text-gray-400 text-sm mb-1">الخدمة</p>
                  <p className="text-white font-semibold">{selectedOrder.service_name}</p>
                </div>
                <div className="bg-white/5 rounded-xl p-4">
                  <p className="text-gray-400 text-sm mb-1">المستخدم</p>
                  <p className="text-white">@{selectedOrder.telegram_username || 'N/A'}</p>
                </div>
                <div className="bg-white/5 rounded-xl p-4">
                  <p className="text-gray-400 text-sm mb-1">الرابط</p>
                  <a
                    href={selectedOrder.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-purple-400 hover:text-purple-300 break-all"
                  >
                    {selectedOrder.link}
                  </a>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-white/5 rounded-xl p-4">
                    <p className="text-gray-400 text-sm mb-1">الكمية المطلوبة</p>
                    <p className="text-white font-semibold">{selectedOrder.quantity}</p>
                  </div>
                  <div className="bg-white/5 rounded-xl p-4">
                    <p className="text-gray-400 text-sm mb-1">الكمية المكتملة</p>
                    <p className="text-white font-semibold">{selectedOrder.completed_quantity || 0}</p>
                  </div>
                </div>
                <div className="bg-white/5 rounded-xl p-4">
                  <p className="text-gray-400 text-sm mb-1">السعر</p>
                  <p className="text-green-400 font-semibold text-xl">${selectedOrder.total_price?.toFixed(2)}</p>
                </div>
                <div className="bg-white/5 rounded-xl p-4">
                  <p className="text-gray-400 text-sm mb-1">الحالة</p>
                  {(() => {
                    const badge = getStatusBadge(selectedOrder.status);
                    return (
                      <span className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-sm ${badge.bg} ${badge.text}`}>
                        {badge.icon}
                        {badge.label}
                      </span>
                    );
                  })()}
                </div>
                {selectedOrder.status !== 'completed' && selectedOrder.status !== 'cancelled' && (
                  <div className="flex gap-3 pt-4">
                    <button
                      onClick={() => {
                        updateOrderStatus(selectedOrder.id, 'processing');
                        setSelectedOrder(null);
                      }}
                      disabled={selectedOrder.status === 'processing'}
                      className="flex-1 px-6 py-3 bg-blue-600 text-white font-semibold rounded-xl hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                    >
                      بدء التنفيذ
                    </button>
                    <button
                      onClick={() => {
                        updateOrderStatus(selectedOrder.id, 'completed', selectedOrder.quantity);
                        setSelectedOrder(null);
                      }}
                      className="flex-1 px-6 py-3 bg-green-600 text-white font-semibold rounded-xl hover:bg-green-700 transition-all"
                    >
                      إكمال الطلب
                    </button>
                    <button
                      onClick={() => {
                        updateOrderStatus(selectedOrder.id, 'cancelled');
                        setSelectedOrder(null);
                      }}
                      className="px-6 py-3 bg-red-600 text-white font-semibold rounded-xl hover:bg-red-700 transition-all"
                    >
                      إلغاء
                    </button>
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </div>
    </div>
  );
}