import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Bot, Save, Key, Globe, Bell, Shield, RefreshCw, DollarSign, Zap, CheckCircle, AlertCircle } from 'lucide-react';

interface Settings {
  profit_margin: number;
  auto_dispatch: boolean;
  auto_check_status: boolean;
  currency: string;
  smm_api_url: string;
  smm_api_key: string;
  bot_token: string;
  bot_username: string;
}

export default function Settings() {
  const [settings, setSettings] = useState<Settings>({
    profit_margin: 20,
    auto_dispatch: true,
    auto_check_status: true,
    currency: 'USD',
    smm_api_url: 'https://smmsharks.com/api/v2',
    smm_api_key: '01b815347b66b2fe9527d631b98bbb3a',
    bot_token: '8775530532:AAGwKw8oUVb-lcod67Sk1GyWpCRr5lVw5og',
    bot_username: 'MadmoonStore_bot'
  });
  const [saved, setSaved] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [syncResult, setSyncResult] = useState<any>(null);
  const [smmBalance, setSmmBalance] = useState<any>(null);

  useEffect(() => {
    fetchSettings();
    fetchSmmBalance();
  }, []);

  const fetchSettings = async () => {
    try {
      const res = await fetch('/api/settings');
      const data = await res.json();
      if (data.profit_margin !== undefined) {
        setSettings(data);
      }
    } catch (err) {
      console.error('Error fetching settings:', err);
    }
  };

  const fetchSmmBalance = async () => {
    try {
      const res = await fetch('/api/smm-balance');
      const data = await res.json();
      setSmmBalance(data);
    } catch (err) {
      console.error('Error fetching SMM balance:', err);
    }
  };

  const handleSave = async () => {
    try {
      const res = await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings)
      });
      if (res.ok) {
        setSaved(true);
        setTimeout(() => setSaved(false), 3000);
      }
    } catch (err) {
      console.error('Error saving settings:', err);
    }
  };

  const handleSyncServices = async () => {
    setSyncing(true);
    setSyncResult(null);
    try {
      const res = await fetch('/api/sync-services', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ margin: settings.profit_margin })
      });
      const data = await res.json();
      setSyncResult(data);
    } catch (err: any) {
      setSyncResult({ success: false, error: err?.message || 'Unknown error' });
    } finally {
      setSyncing(false);
    }
  };

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl font-bold text-white mb-2">الإعدادات</h1>
          <p className="text-gray-400">تكوين البوت والمنصة وربط مزود SMM</p>
        </motion.div>

        {/* SMM Balance Card */}
        {smmBalance && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-gradient-to-br from-green-600/20 to-emerald-600/20 backdrop-blur-sm border border-green-500/30 rounded-2xl p-6 mb-6"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <DollarSign className="w-6 h-6 text-green-400" />
                <div>
                  <p className="text-gray-400 text-sm">رصيد SMM Sharks</p>
                  <p className="text-2xl font-bold text-white">${smmBalance.balance}</p>
                </div>
              </div>
              <button
                onClick={fetchSmmBalance}
                className="p-2 text-green-400 hover:text-green-300 transition-colors"
              >
                <RefreshCw className="w-5 h-5" />
              </button>
            </div>
          </motion.div>
        )}

        {/* SMM Settings */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6 mb-6"
        >
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-cyan-600 rounded-xl flex items-center justify-center">
              <Globe className="w-5 h-5 text-white" />
            </div>
            <h2 className="text-xl font-bold text-white">إعدادات مزود SMM</h2>
          </div>
          <div className="space-y-4">
            <div>
              <label className="block text-gray-400 mb-2">API URL</label>
              <input
                type="url"
                value={settings.smm_api_url}
                onChange={(e) => setSettings({ ...settings, smm_api_url: e.target.value })}
                className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-purple-500"
                placeholder="https://smmsharks.com/api/v2"
              />
            </div>
            <div>
              <label className="block text-gray-400 mb-2">API Key</label>
              <div className="relative">
                <Key className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="password"
                  value={settings.smm_api_key}
                  onChange={(e) => setSettings({ ...settings, smm_api_key: e.target.value })}
                  className="w-full pr-12 pl-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-purple-500"
                  placeholder="API Key from SMM provider"
                />
              </div>
            </div>
            <div>
              <label className="block text-gray-400 mb-2">هامش الربح (%)</label>
              <div className="relative">
                <DollarSign className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="number"
                  min="0"
                  max="200"
                  value={settings.profit_margin}
                  onChange={(e) => setSettings({ ...settings, profit_margin: parseInt(e.target.value) })}
                  className="w-full pr-12 pl-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-purple-500"
                />
              </div>
              <p className="text-gray-500 text-sm mt-2">
                سيتم إضافة {settings.profit_margin}% على أسعار الخدمات الأصلية
              </p>
            </div>
            <div className="flex items-center justify-between py-3 border-t border-white/10">
              <div>
                <p className="text-white font-medium">تنفيذ تلقائي للطلبات</p>
                <p className="text-gray-400 text-sm">إرسال الطلبات تلقائياً لمزود SMM</p>
              </div>
              <button
                onClick={() => setSettings({ ...settings, auto_dispatch: !settings.auto_dispatch })}
                className={`w-14 h-8 rounded-full transition-colors ${
                  settings.auto_dispatch ? 'bg-purple-600' : 'bg-gray-600'
                }`}
              >
                <div
                  className={`w-6 h-6 bg-white rounded-full transition-transform ${
                    settings.auto_dispatch ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>
            <div className="flex items-center justify-between py-3 border-t border-white/10">
              <div>
                <p className="text-white font-medium">فحص الحالة تلقائياً</p>
                <p className="text-gray-400 text-sm">تحديث حالة الطلبات من مزود SMM</p>
              </div>
              <button
                onClick={() => setSettings({ ...settings, auto_check_status: !settings.auto_check_status })}
                className={`w-14 h-8 rounded-full transition-colors ${
                  settings.auto_check_status ? 'bg-purple-600' : 'bg-gray-600'
                }`}
              >
                <div
                  className={`w-6 h-6 bg-white rounded-full transition-transform ${
                    settings.auto_check_status ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>
            <button
              onClick={handleSyncServices}
              disabled={syncing}
              className="w-full px-6 py-3 bg-gradient-to-r from-blue-600 to-cyan-600 text-white font-semibold rounded-xl hover:from-blue-700 hover:to-cyan-700 transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {syncing ? (
                <>
                  <RefreshCw className="w-5 h-5 animate-spin" />
                  جاري المزامنة...
                </>
              ) : (
                <>
                  <RefreshCw className="w-5 h-5" />
                  مزامنة الخدمات من SMM
                </>
              )}
            </button>
            {syncResult && (
              <div className={`p-4 rounded-xl ${syncResult.success ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>
                {syncResult.success ? (
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-5 h-5" />
                    <span>تمت المزامنة: {syncResult.synced} جديدة، {syncResult.updated} محدثة</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <AlertCircle className="w-5 h-5" />
                    <span>خطأ: {syncResult.error}</span>
                  </div>
                )}
              </div>
            )}
          </div>
        </motion.div>

        {/* Bot Settings */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6 mb-6"
        >
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-purple-600 rounded-xl flex items-center justify-center">
              <Bot className="w-5 h-5 text-white" />
            </div>
            <h2 className="text-xl font-bold text-white">إعدادات البوت</h2>
          </div>
          <div className="space-y-4">
            <div>
              <label className="block text-gray-400 mb-2">Bot Username</label>
              <input
                type="text"
                value={settings.bot_username}
                onChange={(e) => setSettings({ ...settings, bot_username: e.target.value })}
                className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-purple-500"
                placeholder="@MadmoonStore_bot"
              />
            </div>
            <div>
              <label className="block text-gray-400 mb-2">Bot Token</label>
              <div className="relative">
                <Key className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="password"
                  value={settings.bot_token}
                  onChange={(e) => setSettings({ ...settings, bot_token: e.target.value })}
                  className="w-full pr-12 pl-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-purple-500"
                  placeholder="123456789:ABCdefGHIjklMNOpqrsTUVwxyz"
                />
              </div>
            </div>
          </div>
        </motion.div>

        {/* General Settings */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6 mb-6"
        >
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-green-600 rounded-xl flex items-center justify-center">
              <Globe className="w-5 h-5 text-white" />
            </div>
            <h2 className="text-xl font-bold text-white">إعدادات عامة</h2>
          </div>
          <div className="space-y-4">
            <div>
              <label className="block text-gray-400 mb-2">العملة</label>
              <select
                value={settings.currency}
                onChange={(e) => setSettings({ ...settings, currency: e.target.value })}
                className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-purple-500"
              >
                <option value="USD" className="bg-slate-900">دولار أمريكي (USD)</option>
                <option value="EUR" className="bg-slate-900">يورو (EUR)</option>
                <option value="SAR" className="bg-slate-900">ريال سعودي (SAR)</option>
                <option value="EGP" className="bg-slate-900">جنيه مصري (EGP)</option>
              </select>
            </div>
          </div>
        </motion.div>

        {/* Setup Guide */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-gradient-to-br from-purple-600/20 to-pink-600/20 backdrop-blur-sm border border-purple-500/30 rounded-2xl p-6 mb-6"
        >
          <div className="flex items-center gap-3 mb-4">
            <Zap className="w-6 h-6 text-purple-400" />
            <h2 className="text-xl font-bold text-white">دليل الإعداد السريع</h2>
          </div>
          <ol className="space-y-3 text-gray-300">
            <li className="flex gap-3">
              <span className="w-6 h-6 bg-purple-600 rounded-full flex items-center justify-center text-white text-sm font-bold flex-shrink-0">1</span>
              <span>اضغط على "مزامنة الخدمات من SMM" لجلب جميع الخدمات تلقائياً</span>
            </li>
            <li className="flex gap-3">
              <span className="w-6 h-6 bg-purple-600 rounded-full flex items-center justify-center text-white text-sm font-bold flex-shrink-0">2</span>
              <span>اضبط هامش الربح المطلوب (مثلاً 20%)</span>
            </li>
            <li className="flex gap-3">
              <span className="w-6 h-6 bg-purple-600 rounded-full flex items-center justify-center text-white text-sm font-bold flex-shrink-0">3</span>
              <span>فعّل "تنفيذ تلقائي للطلبات" لتنفيذ الطلبات مباشرة</span>
            </li>
            <li className="flex gap-3">
              <span className="w-6 h-6 bg-purple-600 rounded-full flex items-center justify-center text-white text-sm font-bold flex-shrink-0">4</span>
              <span>اضغط "حفظ الإعدادات" لحفظ التغييرات</span>
            </li>
          </ol>
        </motion.div>

        {/* Save Button */}
        <motion.button
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          onClick={handleSave}
          className={`w-full px-6 py-4 rounded-xl font-semibold transition-all flex items-center justify-center gap-2 ${
            saved
              ? 'bg-green-600 text-white'
              : 'bg-gradient-to-r from-purple-600 to-pink-600 text-white hover:from-purple-700 hover:to-pink-700'
          }`}
        >
          {saved ? (
            <>
              <CheckCircle className="w-5 h-5" />
              تم الحفظ!
            </>
          ) : (
            <>
              <Save className="w-5 h-5" />
              حفظ الإعدادات
            </>
          )}
        </motion.button>
      </div>
    </div>
  );
}