import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Search, DollarSign, UserPlus, TrendingUp } from 'lucide-react';

interface User {
  id: number;
  telegram_id: string;
  username: string;
  first_name: string;
  balance: number;
  created_at: string;
}

export default function Users() {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showAddBalance, setShowAddBalance] = useState(false);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [balanceAmount, setBalanceAmount] = useState('');

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      const res = await fetch('/api/users');
      const data = await res.json();
      setUsers(data);
    } catch (err) {
      console.error('Error fetching users:', err);
    } finally {
      setLoading(false);
    }
  };

  const addBalance = async () => {
    if (!selectedUser || !balanceAmount) return;
    try {
      const newBalance = selectedUser.balance + parseFloat(balanceAmount);
      await fetch('/api/users', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          telegram_id: selectedUser.telegram_id,
          balance: newBalance
        })
      });
      setShowAddBalance(false);
      setSelectedUser(null);
      setBalanceAmount('');
      fetchUsers();
    } catch (err) {
      console.error('Error adding balance:', err);
    }
  };

  const filteredUsers = users.filter(user => 
    user.username?.toLowerCase().includes(search.toLowerCase()) ||
    user.first_name?.toLowerCase().includes(search.toLowerCase()) ||
    user.telegram_id.includes(search)
  );

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-500"></div>
      </div>
    );
  }

  const totalBalance = users.reduce((sum, user) => sum + (user.balance || 0), 0);

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl font-bold text-white mb-2">المستخدمين</h1>
          <p className="text-gray-400">إدارة المستخدمين وأرصدتهم</p>
        </motion.div>

        {/* Stats */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-gradient-to-br from-purple-600/20 to-pink-600/20 backdrop-blur-sm border border-purple-500/30 rounded-2xl p-6"
          >
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 bg-purple-600 rounded-xl flex items-center justify-center">
                <UserPlus className="w-7 h-7 text-white" />
              </div>
              <div>
                <p className="text-gray-400 text-sm">إجمالي المستخدمين</p>
                <p className="text-3xl font-bold text-white">{users.length}</p>
              </div>
            </div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-gradient-to-br from-green-600/20 to-emerald-600/20 backdrop-blur-sm border border-green-500/30 rounded-2xl p-6"
          >
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 bg-green-600 rounded-xl flex items-center justify-center">
                <DollarSign className="w-7 h-7 text-white" />
              </div>
              <div>
                <p className="text-gray-400 text-sm">إجمالي الأرصدة</p>
                <p className="text-3xl font-bold text-white">${totalBalance.toFixed(2)}</p>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Search */}
        <div className="relative mb-6">
          <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="بحث عن مستخدم..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pr-12 pl-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-purple-500"
          />
        </div>

        {/* Users Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredUsers.map((user, i) => (
            <motion.div
              key={user.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-all"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center text-white font-bold text-lg">
                    {user.first_name?.[0] || user.username?.[0] || '?'}
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white">{user.first_name || 'مستخدم'}</h3>
                    <p className="text-gray-400 text-sm">@{user.username || 'N/A'}</p>
                  </div>
                </div>
              </div>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-gray-400 text-sm">الرصيد</span>
                  <span className="text-green-400 font-bold text-lg">${user.balance?.toFixed(2) || '0.00'}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-400 text-sm">Telegram ID</span>
                  <span className="text-gray-300 text-sm font-mono">{user.telegram_id}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-400 text-sm">تاريخ الانضمام</span>
                  <span className="text-gray-300 text-sm">
                    {new Date(user.created_at).toLocaleDateString('ar-EG')}
                  </span>
                </div>
              </div>
              <button
                onClick={() => {
                  setSelectedUser(user);
                  setShowAddBalance(true);
                }}
                className="w-full mt-4 px-4 py-2 bg-purple-600/20 text-purple-400 font-semibold rounded-xl hover:bg-purple-600/30 transition-all flex items-center justify-center gap-2"
              >
                <DollarSign className="w-4 h-4" />
                شحن رصيد
              </button>
            </motion.div>
          ))}
        </div>

        {/* Add Balance Modal */}
        {showAddBalance && selectedUser && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-slate-900 border border-white/10 rounded-2xl p-6 w-full max-w-md"
            >
              <h2 className="text-2xl font-bold text-white mb-6">شحن رصيد</h2>
              <div className="bg-white/5 rounded-xl p-4 mb-6">
                <p className="text-gray-400 text-sm mb-1">المستخدم</p>
                <p className="text-white font-semibold">{selectedUser.first_name} (@{selectedUser.username})</p>
                <p className="text-gray-400 text-sm mt-2">الرصيد الحالي: <span className="text-green-400">${selectedUser.balance?.toFixed(2)}</span></p>
              </div>
              <div className="mb-6">
                <label className="block text-gray-400 mb-2">المبلغ المراد إضافته</label>
                <div className="relative">
                  <DollarSign className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="number"
                    step="0.01"
                    value={balanceAmount}
                    onChange={(e) => setBalanceAmount(e.target.value)}
                    className="w-full pr-12 pl-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-purple-500"
                    placeholder="0.00"
                  />
                </div>
              </div>
              <div className="flex gap-3">
                <button
                  onClick={() => {
                    setShowAddBalance(false);
                    setSelectedUser(null);
                    setBalanceAmount('');
                  }}
                  className="flex-1 px-6 py-3 bg-white/10 text-white font-semibold rounded-xl hover:bg-white/20 transition-all"
                >
                  إلغاء
                </button>
                <button
                  onClick={addBalance}
                  className="flex-1 px-6 py-3 bg-gradient-to-r from-green-600 to-emerald-600 text-white font-semibold rounded-xl hover:from-green-700 hover:to-emerald-700 transition-all"
                >
                  تأكيد الشحن
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </div>
    </div>
  );
}