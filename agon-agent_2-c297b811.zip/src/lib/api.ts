// Client-side API calls (bypasses serverless functions)

const API_BASE = window.location.origin;

export async function fetchAPI(endpoint: string, options: RequestInit = {}) {
  try {
    const response = await fetch(`${API_BASE}/api/${endpoint}`, {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      ...options,
    });
    
    if (!response.ok) {
      throw new Error(`API Error: ${response.status}`);
    }
    
    return await response.json();
  } catch (error) {
    console.error('API Error:', error);
    throw error;
  }
}

export const api = {
  services: {
    getAll: () => fetchAPI('services'),
    create: (data: any) => fetchAPI('services', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
    update: (data: any) => fetchAPI('services', {
      method: 'PUT',
      body: JSON.stringify(data),
    }),
    delete: (data: any) => fetchAPI('services', {
      method: 'DELETE',
      body: JSON.stringify(data),
    }),
    sync: (margin: number) => fetchAPI('sync-services', {
      method: 'POST',
      body: JSON.stringify({ margin }),
    }),
  },
  orders: {
    getAll: (params?: Record<string, string>) => {
      const queryString = params ? `?${new URLSearchParams(params)}` : '';
      return fetchAPI(`orders${queryString}`);
    },
    create: (data: any) => fetchAPI('telegram-order', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
    update: (data: any) => fetchAPI('orders', {
      method: 'PUT',
      body: JSON.stringify(data),
    }),
    dispatch: (orderId: number) => fetchAPI('dispatch-order', {
      method: 'POST',
      body: JSON.stringify({ orderId }),
    }),
    checkStatus: (orderId: number) => fetchAPI('check-status', {
      method: 'POST',
      body: JSON.stringify({ orderId }),
    }),
  },
  users: {
    getAll: () => fetchAPI('users'),
    get: (telegramId: string) => {
      const queryString = telegramId ? `?telegram_id=${telegramId}` : '';
      return fetchAPI(`users${queryString}`);
    },
    create: (data: any) => fetchAPI('users', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
    update: (data: any) => fetchAPI('users', {
      method: 'PUT',
      body: JSON.stringify(data),
    }),
  },
  stats: {
    get: () => fetchAPI('stats'),
  },
  settings: {
    get: () => fetchAPI('settings'),
    update: (data: any) => fetchAPI('settings', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
  },
  smm: {
    getBalance: () => fetchAPI('smm-balance'),
  },
};
