# 🚀 MadmoonStore Bot - دليل النشر الكامل على Netlify

## ✅ المشروع جاهز للنشر!

### 📁 الملفات المضمنة:

#### 1️⃣ ملفات API (16 ملف):
- `_supabase.js` - اتصال قاعدة البيانات
- `_wake.js` - إعادة استعادة قاعدة البيانات
- `telegram.js` - بوت تيليجرام كامل
- `telegram-order.js` - إنشاء الطلبات من البوت
- `services.js` - إدارة الخدمات
- `orders.js` - إدارة الطلبات
- `users.js` - إدارة المستخدمين
- `stats.js` - الإحصائيات
- `settings.js` - الإعدادات
- `smm.js` - ربط SMM Sharks ⭐
- `sync-services.js` - مزامنة الخدمات من SMM ⭐
- `dispatch-order.js` - إرسال الطلبات لـ SMM ⭐
- `check-status.js` - فحص حالة الطلبات من SMM ⭐
- `smm-balance.js` - رصيد SMM ⭐
- `package.json` - تبعيات API

#### 2️⃣ صفحات React (7 صفحات):
- `Home.tsx` - الصفحة الرئيسية
- `Dashboard.tsx` - لوحة التحكم
- `Services.tsx` - إدارة الخدمات
- `Orders.tsx` - إدارة الطلبات
- `Users.tsx` - إدارة المستخدمين
- `Settings.tsx` - الإعدادات
- `Navbar.tsx` - شريط التنقل

#### 3️⃣ ملفات التكوين:
- `netlify.toml` - إعدادات Netlify
- `package.json` - تبعيات المشروع
- `vite.config.ts` - إعدادات Vite
- `tsconfig.json` - إعدادات TypeScript

---

## 📋 خطوات النشر على Netlify:

### الطريقة الأولى: عبر واجهة الويب (الأسهل)

#### الخطوة 1: إنشاء حساب
1. اذهب إلى: https://app.netlify.com/signup
2. سجل حساباً جديداً (مجاني بالكامل)

#### الخطوة 2: ربط المشروع
1. اضغط "Add new site" → "Import an existing project"
2. اختر "GitHub" واسمح بالوصول
3. ابحث عن مستودع المشروع

**إذا لم يكن المشروع على GitHub:**
1. اضغط "Deploy manually"
2. اسحب وأفلت مجلد المشروع بالكامل
3. اضغط "Deploy site"

#### الخطوة 3: إعدادات البناء
في صفحة "Build & deploy":
```
Build command: npm run build
Publish directory: dist
```

#### الخطوة 4: إضافة متغيرات البيئة ⭐ مهم جداً

اذهب إلى: Site settings → Environment variables → Add variable

أضف المتغيرات التالية بالضبط:

```
NEXT_PUBLIC_SUPABASE_URL
= https://zdjzdgxwhtjedknrzxmx.supabase.co

NEXT_PUBLIC_SUPABASE_ANON_KEY
= sb_publishable_VGUQhIqd0T6kN-PVN8I1gw_W7ZYO3-B

SUPABASE_SERVICE_ROLE_KEY
= sb_secret_Yg6OV3hl7Ie1fYN0xuebcQ_nIsnBu4p

VITE_SUPABASE_URL
= https://zdjzdgxwhtjedknrzxmx.supabase.co

VITE_SUPABASE_ANON_KEY
= sb_publishable_VGUQhIqd0T6kN-PVN8I1gw_W7ZYO3-B

TELEGRAM_BOT_TOKEN
= 8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU

SMM_API_URL
= https://smmsharks.com/api/v2

SMM_API_KEY
= 01b815347b66b2fe9527d631b98bbb3a
```

#### الخطوة 5: النشر
1. اضغط "Deploy site"
2. انتظر حتى يكتمل النشر (حوالي 2-3 دقائق)
3. سيظهر رابط الموقع مثل: `https://madmoonstore-bot.netlify.app`

---

### الطريقة الثانية: عبر Netlify CLI (أسرع للمطورين)

#### 1️⃣ تثبيت Netlify CLI
```bash
npm install -g netlify-cli
```

#### 2️⃣ تسجيل الدخول
```bash
netlify login
```

#### 3️⃣ تهيئة المشروع
```bash
netlify init
```
- اختر: "Create & configure a new site"
- اختر فريقك
- أدخل اسم الموقع: `madmoonstore-bot`

#### 4️⃣ إضافة متغيرات البيئة
```bash
netlify env:set NEXT_PUBLIC_SUPABASE_URL "https://zdjzdgxwhtjedknrzxmx.supabase.co"
netlify env:set NEXT_PUBLIC_SUPABASE_ANON_KEY "sb_publishable_VGUQhIqd0T6kN-PVN8I1gw_W7ZYO3-B"
netlify env:set SUPABASE_SERVICE_ROLE_KEY "sb_secret_Yg6OV3hl7Ie1fYN0xuebcQ_nIsnBu4p"
netlify env:set VITE_SUPABASE_URL "https://zdjzdgxwhtjedknrzxmx.supabase.co"
netlify env:set VITE_SUPABASE_ANON_KEY "sb_publishable_VGUQhIqd0T6kN-PVN8I1gw_W7ZYO3-B"
netlify env:set TELEGRAM_BOT_TOKEN "8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU"
netlify env:set SMM_API_URL "https://smmsharks.com/api/v2"
netlify env:set SMM_API_KEY "01b815347b66b2fe9527d631b98bbb3a"
```

#### 5️⃣ النشر
```bash
netlify deploy --prod
```

---

## 🔧 بعد النشر:

### 1️⃣ الحصول على رابط الموقع
بعد النشر الناجح، ستحصل على رابط مثل:
```
https://madmoonstore-bot.netlify.app
```

### 2️⃣ إعداد Webhook للبوت ⭐ مهم جداً

استبدل `YOUR_SITE_URL` برابط موقعك الفعلي:

```bash
curl -F "url=https://YOUR_SITE_URL.netlify.app/api/telegram" \
  https://api.telegram.org/bot8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU/setWebhook
```

**مثال:**
```bash
curl -F "url=https://madmoonstore-bot.netlify.app/api/telegram" \
  https://api.telegram.org/bot8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU/setWebhook
```

### 3️⃣ التحقق من Webhook
```bash
curl https://api.telegram.org/bot8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU/getWebhookInfo
```

يجب أن ترى:
```json
{
  "ok": true,
  "result": {
    "url": "https://YOUR_SITE_URL.netlify.app/api/telegram",
    "has_custom_certificate": false,
    "pending_update_count": 0
  }
}
```

### 4️⃣ اختبار البوت
1. افتح تيليجرام
2. ابحث عن: `@MadmoonStore_bot`
3. اكتب: `/start`
4. جرب الخدمات!

---

## 🎯 روابط المشروع بعد النشر:

### لوحة التحكم:
```
https://YOUR_SITE_URL.netlify.app/dashboard
```

### الصفحات الرئيسية:
- **الرئيسية:** `https://YOUR_SITE_URL.netlify.app/`
- **الخدمات:** `https://YOUR_SITE_URL.netlify.app/services`
- **الطلبات:** `https://YOUR_SITE_URL.netlify.app/orders`
- **المستخدمين:** `https://YOUR_SITE_URL.netlify.app/users`
- **الإعدادات:** `https://YOUR_SITE_URL.netlify.app/settings`

### API Endpoints:
- **الخدمات:** `https://YOUR_SITE_URL.netlify.app/api/services`
- **الطلبات:** `https://YOUR_SITE_URL.netlify.app/api/orders`
- **المستخدمين:** `https://YOUR_SITE_URL.netlify.app/api/users`
- **الإحصائيات:** `https://YOUR_SITE_URL.netlify.app/api/stats`
- **مزامنة الخدمات:** `https://YOUR_SITE_URL.netlify.app/api/sync-services`
- **رصيد SMM:** `https://YOUR_SITE_URL.netlify.app/api/smm-balance`

---

## ✅ التحقق من النشر:

### اختبار API:
```bash
curl https://YOUR_SITE_URL.netlify.app/api/services
```

يجب أن ترى قائمة بالخدمات.

### اختبار ربط SMM:
```bash
curl https://YOUR_SITE_URL.netlify.app/api/smm-balance
```

يجب أن ترى:
```json
{
  "success": true,
  "balance": "6.9980441",
  "currency": "USD"
}
```

### اختبار البوت:
افتح تيليجرام واكتب `/start` في البوت.

---

## 📊 نظام الربط مع SMM Sharks:

### الميزات المتوفرة:
1. ✅ مزامنة تلقائية للخدمات من SMM
2. ✅ إضافة هامش ربح تلقائي (20% افتراضي)
3. ✅ إرسال الطلبات تلقائياً لـ SMM
4. ✅ فحص حالة الطلبات من SMM
5. ✅ عرض رصيد SMM

### كيفية الاستخدام:

#### 1) مزامنة الخدمات:
- اذهب إلى "الخدمات" في لوحة التحكم
- اضغط "مزامنة من SMM"
- سيتم جلب جميع الخدمات مع هامش ربح 20%

#### 2) تنفيذ الطلبات:
- الطلبات تُرسل تلقائياً لـ SMM عند الإنشاء
- أو اضغط "إرسال إلى SMM" يدوياً من صفحة الطلبات

#### 3) تحديث الحالة:
- اضغط "تحديث الحالة من SMM" لفحص حالة الطلب
- ستُحدث الحالة تلقائياً بناءً على رد SMM

---

## 🎉 مبروك! البوت جاهز للاستخدام!

### الخطوات التالية:

1. **شحن رصيد SMM:**
   - ادخل: https://smmsharks.com
   - اشحن رصيداً كافياً للطلبات

2. **مزامنة الخدمات:**
   - من لوحة التحكم → الخدمات
   - اضغط "مزامنة من SMM"

3. **شحن أرصدة المستخدمين:**
   - من لوحة التحكم → المستخدمين
   - اضغط "شحن رصيد"

4. **ابدأ التسويق:**
   - شارك رابط البوت: @MadmoonStore_bot
   - شارك رابط الموقع

---

## 📞 الدعم:

### إذا واجهت مشاكل:

1. **تحقق من السجلات:**
   - اذهب إلى Netlify Dashboard
   - اختر موقعك
   - اضغط "Functions" → "View logs"

2. **تأكد من متغيرات البيئة:**
   - Site settings → Environment variables
   - تأكد من إضافة جميع المتغيرات

3. **أعد النشر:**
   - اضغط "Deploys" → "Trigger deploy" → "Deploy site"

4. **تحقق من Webhook:**
   ```bash
   curl https://api.telegram.org/bot8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU/getWebhookInfo
   ```

---

## 🚀 النظام الكامل يتضمن:

✅ بوت تيليجرام متكامل
✅ لوحة تحكم احترافية
✅ ربط تلقائي مع SMM Sharks
✅ قاعدة بيانات Supabase
✅ مزامنة الخدمات التلقائية
✅ تنفيذ الطلبات التلقائي
✅ نظام شحن الأرصدة
✅ إحصائيات شاملة
✅ إدارة المستخدمين
✅ تعديل هامش الربح

**ابدأ الآن واستمتع بالأرباح! 💎**
