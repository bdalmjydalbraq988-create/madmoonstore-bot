import supabase from './_supabase.js';
import { createOrder as createSMMOrder } from './smm.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'POST') {
      const { service_id, telegram_id, telegram_username, link, quantity } = req.body;
      
      // Get service details
      const { data: service } = await supabase
        .from('services')
        .select('*')
        .eq('id', service_id)
        .single();
      
      if (!service) {
        return res.status(404).json({ error: 'Service not found' });
      }
      
      // Get user balance
      const { data: user } = await supabase
        .from('users')
        .select('balance')
        .eq('telegram_id', telegram_id.toString())
        .single();
      
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }
      
      // Calculate total price
      const totalPrice = (service.price_per_1000 * quantity) / 1000;
      
      // Check balance
      if (user.balance < totalPrice) {
        return res.status(400).json({ 
          error: 'Insufficient balance',
          required: totalPrice,
          current: user.balance
        });
      
      // Deduct balance
      await supabase
        .from('users')
        .update({ balance: user.balance - totalPrice })
        .eq('telegram_id', telegram_id.toString());
      
      // Create order in our database
      const { data: order, error: orderError } = await supabase
        .from('orders')
        .insert({
          service_id,
          service_name: service.name,
          telegram_id: telegram_id.toString(),
          telegram_username,
          link,
          quantity,
          total_price: totalPrice,
          status: 'pending'
        })
        .select()
        .single();
      
      if (orderError) {
        // Refund balance if order creation failed
        await supabase
          .from('users')
          .update({ balance: user.balance })
          .eq('telegram_id', telegram_id.toString());
        throw orderError;
      }
      
      // Auto-dispatch to SMM provider
      if (service.smm_service_id) {
        try {
          const smmOrder = await createSMMOrder(
            service.smm_service_id,
            link,
            quantity
          );
          
          // Update order with SMM details
          await supabase
            .from('orders')
            .update({
              smm_order_id: smmOrder.order,
              status: 'processing',
              smm_response: JSON.stringify(smmOrder)
            })
            .eq('id', order.id);
        } catch (smmError) {
          console.error('SMM dispatch error:', smmError);
          // Order created but not dispatched - admin can retry
        }
      }
      
      return res.status(201).json({
        success: true,
        order,
        message: 'Order created successfully'
      });
    }
    
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Telegram order error:', err);
    res.status(500).json({ error: err.message });
  }
}