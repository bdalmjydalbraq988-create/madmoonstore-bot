import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      // Get total users
      const { count: usersCount } = await supabase
        .from('users')
        .select('*', { count: 'exact', head: true });
      
      // Get total orders
      const { count: ordersCount } = await supabase
        .from('orders')
        .select('*', { count: 'exact', head: true });
      
      // Get total revenue
      const { data: orders } = await supabase
        .from('orders')
        .select('total_price')
        .eq('status', 'completed');
      
      const totalRevenue = orders?.reduce((sum, o) => sum + (o.total_price || 0), 0) || 0;
      
      // Get orders by status
      const { data: ordersByStatus } = await supabase
        .from('orders')
        .select('status');
      
      const statusCounts = {
        pending: 0,
        processing: 0,
        completed: 0,
        cancelled: 0
      };
      
      ordersByStatus?.forEach(o => {
        if (statusCounts[o.status] !== undefined) {
          statusCounts[o.status]++;
        }
      });
      
      // Get recent orders
      const { data: recentOrders } = await supabase
        .from('orders')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(10);
      
      return res.status(200).json({
        usersCount: usersCount || 0,
        ordersCount: ordersCount || 0,
        totalRevenue,
        statusCounts,
        recentOrders: recentOrders || []
      });
    }
    
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}