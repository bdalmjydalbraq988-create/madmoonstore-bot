import supabase from './_supabase.js';
import { checkOrderStatus } from './smm.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'POST') {
      const { orderId } = req.body;
      
      // Get order details
      const { data: order, error: orderError } = await supabase
        .from('orders')
        .select('*')
        .eq('id', orderId)
        .single();
      
      if (orderError || !order) {
        return res.status(404).json({ error: 'Order not found' });
      }
      
      if (!order.smm_order_id) {
        return res.status(400).json({ error: 'Order not dispatched to SMM provider' });
      }
      
      // Check status with SMM provider
      const status = await checkOrderStatus(order.smm_order_id);
      
      // Map SMM status to our status
      const mappedStatus = mapSMMStatus(status.status);
      
      // Update order status
      await supabase
        .from('orders')
        .update({
          status: mappedStatus,
          completed_quantity: parseInt(status.start_count) + parseInt(status.remains) || order.quantity,
          smm_status: status.status,
          smm_response: JSON.stringify(status)
        })
        .eq('id', orderId);
      
      return res.status(200).json({
        success: true,
        status: mappedStatus,
        smmStatus: status.status,
        startCount: status.start_count,
        remains: status.remains
      });
    }
    
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Check status error:', err);
    res.status(500).json({ error: err.message });
  }
}

function mapSMMStatus(smmStatus) {
  const statusMap = {
    'Pending': 'pending',
    'Processing': 'processing',
    'In progress': 'processing',
    'Completed': 'completed',
    'Cancelled': 'cancelled',
    'Partial': 'partial',
    'Failed': 'cancelled'
  };
  
  return statusMap[smmStatus] || 'pending';
}