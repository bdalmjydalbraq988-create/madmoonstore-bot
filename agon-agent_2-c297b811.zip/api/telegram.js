import supabase from './_supabase.js';

// Store pending orders in memory (in production, use Redis or database)
const pendingOrders = new Map();

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'POST') {
      const { message, callback_query } = req.body;
      
      const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || '8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU';
      
      // Handle message
      if (message) {
        await handleMessage(message, BOT_TOKEN);
      }
      
      // Handle callback query
      if (callback_query) {
        await handleCallbackQuery(callback_query, BOT_TOKEN);
      }
      
      return res.status(200).json({ ok: true });
    }
    
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Telegram API error:', err);
    res.status(500).json({ error: err.message });
  }
}

async function sendMessage(chatId, text, replyMarkup = null) {
  const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || '8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU';
  const url = `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`;
  
  const payload = {
    chat_id: chatId,
    text,
    parse_mode: 'HTML'
  };
  
  if (replyMarkup) {
    payload.reply_markup = replyMarkup;
  }
  
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  
  return response.json();
}

async function handleMessage(message, BOT_TOKEN) {
  const chatId = message.chat.id;
  const text = message.text || '';
  const user = message.from;
  
  // Register or update user
  await fetch(`${process.env.VERCEL_URL || 'http://localhost:3000'}/api/users`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      telegram_id: user.id.toString(),
      username: user.username,
      first_name: user.first_name
    })
  });
  
  // Check if user is waiting for link input
  const pendingOrder = pendingOrders.get(chatId.toString());
  if (pendingOrder && pendingOrder.step === 'waiting_link') {
    if (!text.startsWith('http')) {
      await sendMessage(chatId, '❌ الرابط غير صحيح. يرجى إدخال رابط يبدأ بـ http:// أو https://');
      return;
    }
    pendingOrder.link = text;
    pendingOrder.step = 'waiting_quantity';
    pendingOrders.set(chatId.toString(), pendingOrder);
    
    await sendMessage(
      chatId,
      `✅ تم حفظ الرابط!\n\n📊 <b>الكمية المطلوبة:</b>\nالحد الأدنى: ${pendingOrder.min_order}\nالحد الأقصى: ${pendingOrder.max_order}\n\nالسعر: $${(pendingOrder.price_per_1000 * 1000 / 1000).toFixed(2)} لكل 1000\n\nأدخل الكمية المطلوبة:`
    );
    return;
  }
  
  // Check if user is waiting for quantity input
  if (pendingOrder && pendingOrder.step === 'waiting_quantity') {
    const quantity = parseInt(text);
    if (isNaN(quantity) || quantity < pendingOrder.min_order || quantity > pendingOrder.max_order) {
      await sendMessage(chatId, `❌ الكمية غير صحيحة. يجب أن تكون بين ${pendingOrder.min_order} و ${pendingOrder.max_order}`);
      return;
    }
    
    pendingOrder.quantity = quantity;
    pendingOrders.set(chatId.toString(), pendingOrder);
    
    const totalPrice = (pendingOrder.price_per_1000 * quantity) / 1000;
    
    const confirmKeyboard = {
      inline_keyboard: [
        [
          { text: '✅ تأكيد الطلب', callback_data: `confirm_order_${chatId}` },
          { text: '❌ إلغاء', callback_data: `cancel_order_${chatId}` }
        ]
      ]
    };
    
    await sendMessage(
      chatId,
      `📋 <b>تأكيد الطلب:</b>\n\n🔹 الخدمة: ${pendingOrder.service_name}\n🔹 الرابط: ${pendingOrder.link}\n🔹 الكمية: ${quantity}\n💰 السعر: $${totalPrice.toFixed(2)}\n\nتأكيد الطلب؟`,
      confirmKeyboard
    );
    return;
  }
  
  if (text === '/start') {
    const welcomeMessage = `
🎉 <b>مرحباً بك في بوت MadmoonStore!</b>

🤖 بوت متكامل لزيادة المتابعين والتفاعل

📋 <b>القائمة الرئيسية:</b>

🛒 <b>طلب خدمة</b> - اختر الخدمة المطلوبة

📊 <b>طلباتي</b> - تتبع طلباتك الحالية

💰 <b>رصيدي</b> - معرفة رصيدك الحالي

📞 <b>دعم فني</b> - التواصل مع الدعم

━━━━━━━━━━━━━━━
🚀 ابدأ الآن بالضغط على الأزرار أدناه!
    `;
    
    const keyboard = {
      inline_keyboard: [
        [
          { text: '🛒 طلب خدمة', callback_data: 'menu_services' },
          { text: '📊 طلباتي', callback_data: 'menu_orders' }
        ],
        [
          { text: '💰 رصيدي', callback_data: 'menu_balance' },
          { text: '📞 دعم فني', callback_data: 'menu_support' }
        ]
      ]
    };
    
    await sendMessage(chatId, welcomeMessage, keyboard);
  } else if (text === '/help') {
    const helpMessage = `
❓ <b>كيفية استخدام البوت:</b>

1️⃣ اختر الخدمة المطلوبة من القائمة
2️⃣ أدخل الرابط المراد رفعه
3️⃣ حدد الكمية المطلوبة
4️⃣ تأكيد الطلب

━━━━━━━━━━━━━━━
⚠️ <b>ملاحظات هامة:</b>

• تأكد من أن حسابك عام
• لا تقم بإغلاق حسابك أثناء التنفيذ
• الدعم الفني متاح 24/7

📞 للتواصل: @support
    `;
    await sendMessage(chatId, helpMessage);
  } else {
    await sendMessage(chatId, '👋 أهلاً! استخدم /start للبدء');
  }
}

async function handleCallbackQuery(callbackQuery, BOT_TOKEN) {
  const { id, data, from, message } = callbackQuery;
  const chatId = message.chat.id;
  const userId = from.id.toString();
  
  // Answer callback query
  await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/answerCallbackQuery`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ callback_query_id: id })
  });
  
  if (data === 'menu_services') {
    await showServicesMenu(chatId);
  } else if (data === 'menu_orders') {
    await showUserOrders(chatId, userId);
  } else if (data === 'menu_balance') {
    await showUserBalance(chatId, userId);
  } else if (data === 'menu_support') {
    await sendMessage(chatId, '📞 <b>الدعم الفني</b>\\n\\nللتواصل معنا:\\n• تيليجرام: @support\\n• إيميل: support@madmoonstore.com\\n\\n✅ نرد على جميع الاستفسارات خلال 24 ساعة');
  } else if (data.startsWith('category_')) {
    const category = data.replace('category_', '');
    await showCategoryServices(chatId, category);
  } else if (data.startsWith('service_')) {
    const serviceId = data.replace('service_', '');
    await selectService(chatId, serviceId, userId, from.username);
  } else if (data === `confirm_order_${chatId}`) {
    await confirmOrder(chatId, userId, from.username);
  } else if (data === `cancel_order_${chatId}`) {
    pendingOrders.delete(chatId.toString());
    await sendMessage(chatId, '❌ تم إلغاء الطلب');
  }
}

async function showServicesMenu(chatId) {
  const keyboard = {
    inline_keyboard: [
      [
        { text: '📱 انستقرام', callback_data: 'category_instagram' },
        { text: '🐦 تويتر X', callback_data: 'category_twitter' }
      ],
      [
        { text: '📺 تيك توك', callback_data: 'category_tiktok' },
        { text: '🎵 يوتيوب', callback_data: 'category_youtube' }
      ],
      [
        { text: '📘 فيسبوك', callback_data: 'category_facebook' },
        { text: '✈️ تيليجرام', callback_data: 'category_telegram' }
      ],
      [{ text: '🔙 رجوع', callback_data: 'menu_main' }]
    ]
  };
  
  await sendMessage(chatId, '🛒 <b>اختر المنصة:</b>', keyboard);
}

async function showCategoryServices(chatId, category) {
  const response = await fetch(`${process.env.VERCEL_URL || 'http://localhost:3000'}/api/services`);
  const services = await response.json();
  
  const categoryServices = services.filter(s => s.category === category);
  
  if (categoryServices.length === 0) {
    await sendMessage(chatId, '❌ لا توجد خدمات متاحة في هذه الفئة حالياً');
    return;
  }
  
  const buttons = categoryServices.slice(0, 10).map(s => ({
    text: `${s.name} - $${s.price_per_1000}/1000`,
    callback_data: `service_${s.id}`
  }));
  
  const keyboard = {
    inline_keyboard: [
      ...buttons.map(b => [b]),
      [{ text: '🔙 رجوع', callback_data: 'menu_services' }]
    ]
  };
  
  await sendMessage(chatId, `📋 <b>خدمات ${category}:</b>`, keyboard);
}

async function selectService(chatId, serviceId, userId, username) {
  const response = await fetch(`${process.env.VERCEL_URL || 'http://localhost:3000'}/api/services`);
  const services = await response.json();
  const service = services.find(s => s.id === parseInt(serviceId));
  
  if (!service) {
    await sendMessage(chatId, '❌ الخدمة غير موجودة');
    return;
  }
  
  // Store pending order
  pendingOrders.set(chatId.toString(), {
    service_id: service.id,
    service_name: service.name,
    price_per_1000: service.price_per_1000,
    min_order: service.min_order,
    max_order: service.max_order,
    step: 'waiting_link'
  });
  
  const message = `
📦 <b>${service.name}</b>

💰 <b>السعر:</b> $${service.price_per_1000} لكل 1000

📊 <b>الحد الأدنى:</b> ${service.min_order}
📊 <b>الحد الأقصى:</b> ${service.max_order}

━━━━━━━━━━━━━━━
📝 <b>الخطوة 1/3:</b>
أدخل الرابط المراد رفعه:
  `;
  
  await sendMessage(chatId, message);
}

async function confirmOrder(chatId, userId, username) {
  const pendingOrder = pendingOrders.get(chatId.toString());
  
  if (!pendingOrder) {
    await sendMessage(chatId, '❌ لم يتم العثور على الطلب');
    return;
  }
  
  try {
    const totalPrice = (pendingOrder.price_per_1000 * pendingOrder.quantity) / 1000;
    
    // Create order via API
    const res = await fetch(`${process.env.VERCEL_URL || 'http://localhost:3000'}/api/telegram-order`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        service_id: pendingOrder.service_id,
        telegram_id: userId,
        telegram_username: username,
        link: pendingOrder.link,
        quantity: pendingOrder.quantity
      })
    });
    
    const data = await res.json();
    
    if (data.success) {
      pendingOrders.delete(chatId.toString());
      
      const successMessage = `
✅ <b>تم إنشاء الطلب بنجاح!</b>

📋 <b>تفاصيل الطلب:</b>
🔹 رقم الطلب: #${data.order.id}
🔹 الخدمة: ${pendingOrder.service_name}
🔹 الكمية: ${pendingOrder.quantity}
💰 السعر: $${totalPrice.toFixed(2)}
📊 الحالة: ${data.order.status === 'processing' ? 'قيد التنفيذ' : 'قيد الانتظار'}

━━━━━━━━━━━━━━━
📊 تابع حالة طلبك من "طلباتي"
      `;
      
      await sendMessage(chatId, successMessage);
    } else {
      await sendMessage(chatId, `❌ فشل إنشاء الطلب: ${data.error}`);
    }
  } catch (err) {
    console.error('Order creation error:', err);
    await sendMessage(chatId, '❌ حدث خطأ أثناء إنشاء الطلب');
  }
}

async function showUserOrders(chatId, telegramId) {
  const response = await fetch(`${process.env.VERCEL_URL || 'http://localhost:3000'}/api/orders?telegram_id=${telegramId}`);
  const orders = await response.json();
  
  if (orders.length === 0) {
    await sendMessage(chatId, '📊 <b>طلباتي</b>\\n\\nلا توجد طلبات حالياً');
    return;
  }
  
  const message = orders.slice(0, 5).map((order, i) => 
    `${i + 1}. ${order.service_name}\\n   الكمية: ${order.quantity}\\n   الحالة: ${getStatusEmoji(order.status)} ${order.status}\\n   السعر: $${order.total_price}`
  ).join('\\n\\n');
  
  await sendMessage(chatId, `📊 <b>آخر الطلبات:</b>\\n\\n${message}`);
}

async function showUserBalance(chatId, telegramId) {
  const response = await fetch(`${process.env.VERCEL_URL || 'http://localhost:3000'}/api/users?telegram_id=${telegramId}`);
  const user = await response.json();
  
  const balance = user ? user.balance : 0;
  
  const message = `
💰 <b>رصيدك الحالي:</b>

💵 $${balance.toFixed(2)}

━━━━━━━━━━━━━━━
📥 <b>للشحن:</b>
تواصل مع الدعم الفني
📞 @support
  `;
  
  await sendMessage(chatId, message);
}

function getStatusEmoji(status) {
  const emojis = {
    pending: '⏳',
    processing: '🔄',
    completed: '✅',
    cancelled: '❌',
    partial: '⚠️'
  };
  return emojis[status] || '❓';
}
