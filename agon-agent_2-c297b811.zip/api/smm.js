// SMM Provider Integration
const SMM_CONFIG = {
  apiUrl: process.env.SMM_API_URL || 'https://smmsharks.com/api/v2',
  apiKey: process.env.SMM_API_KEY || '01b815347b66b2fe9527d631b98bbb3a'
};

export async function fetchServices() {
  try {
    const response = await fetch(`${SMM_CONFIG.apiUrl}?action=services&key=${SMM_CONFIG.apiKey}`);
    const data = await response.json();
    
    if (data.error) {
      throw new Error(data.error);
    }
    
    return data;
  } catch (error) {
    console.error('Error fetching services:', error);
    throw error;
  }
}

export async function createOrder(serviceId, link, quantity) {
  try {
    const response = await fetch(
      `${SMM_CONFIG.apiUrl}?action=add&key=${SMM_CONFIG.apiKey}&service=${serviceId}&link=${encodeURIComponent(link)}&quantity=${quantity}`
    );
    const data = await response.json();
    
    if (data.error) {
      throw new Error(data.error);
    }
    
    return data;
  } catch (error) {
    console.error('Error creating order:', error);
    throw error;
  }
}

export async function checkOrderStatus(orderId) {
  try {
    const response = await fetch(
      `${SMM_CONFIG.apiUrl}?action=status&key=${SMM_CONFIG.apiKey}&order=${orderId}`
    );
    const data = await response.json();
    
    if (data.error) {
      throw new Error(data.error);
    }
    
    return data;
  } catch (error) {
    console.error('Error checking order status:', error);
    throw error;
  }
}

export async function getBalance() {
  try {
    const response = await fetch(
      `${SMM_CONFIG.apiUrl}?action=balance&key=${SMM_CONFIG.apiKey}`
    );
    const data = await response.json();
    
    if (data.error) {
      throw new Error(data.error);
    }
    
    return data;
  } catch (error) {
    console.error('Error getting balance:', error);
    throw error;
  }
}

export async function syncServices() {
  try {
    const services = await fetchServices();
    return services;
  } catch (error) {
    throw error;
  }
}

export default {
  fetchServices,
  createOrder,
  checkOrderStatus,
  getBalance,
  syncServices
};