import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { telegram_id, status, limit = 50 } = req.query;
      let query = supabase.from('orders').select('*').order('created_at', { ascending: false }).limit(limit);
      
      if (telegram_id) query = query.eq('telegram_id', telegram_id);
      if (status) query = query.eq('status', status);
      
      const { data, error } = await query;
      if (error) throw error;
      return res.status(200).json(data);
    }
    
    if (req.method === 'POST') {
      const { service_id, telegram_id, telegram_username, link, quantity, total_price } = req.body;
      
      // Get service details
      const { data: service } = await supabase.from('services').select('*').eq('id', service_id).single();
      
      const { data, error } = await supabase
        .from('orders')
        .insert({
          service_id,
          service_name: service.name,
          telegram_id,
          telegram_username,
          link,
          quantity,
          total_price,
          status: 'pending'
        })
        .select()
        .single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    
    if (req.method === 'PUT') {
      const { id, status, completed_quantity } = req.body;
      const updates = {};
      if (status) updates.status = status;
      if (completed_quantity !== undefined) updates.completed_quantity = completed_quantity;
      
      const { data, error } = await supabase
        .from('orders')
        .update(updates)
        .eq('id', id)
        .select()
        .single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}