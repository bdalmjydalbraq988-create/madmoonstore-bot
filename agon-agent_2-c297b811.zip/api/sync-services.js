import supabase from './_supabase.js';
import { fetchServices } from './smm.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'POST') {
      const { margin } = req.body;
      
      // Fetch services from SMM provider
      const smmServices = await fetchServices();
      
      let synced = 0;
      let updated = 0;
      
      for (const service of smmServices) {
        // Calculate price with margin
        const originalPrice = parseFloat(service.rate);
        const marginPercent = margin || 20; // Default 20% margin
        const adjustedPrice = originalPrice * (1 + marginPercent / 100);
        
        // Map SMM categories to our categories
        const category = mapCategory(service.category);
        
        // Check if service exists
        const { data: existing } = await supabase
          .from('services')
          .select('id')
          .eq('smm_service_id', service.service)
          .single();
        
        if (existing) {
          // Update existing service
          await supabase
            .from('services')
            .update({
              name: service.name,
              category,
              price_per_1000: adjustedPrice,
              min_order: parseInt(service.min),
              max_order: parseInt(service.max),
              description: `Original: $${originalPrice}/1000`
            })
            .eq('id', existing.id);
          updated++;
        } else {
          // Insert new service
          await supabase
            .from('services')
            .insert({
              name: service.name,
              category,
              price_per_1000: adjustedPrice,
              min_order: parseInt(service.min),
              max_order: parseInt(service.max),
              description: `Original: $${originalPrice}/1000`,
              smm_service_id: service.service.toString(),
              original_price: originalPrice
            });
          synced++;
        }
      }
      
      return res.status(200).json({
        success: true,
        synced,
        updated,
        total: smmServices.length
      });
    }
    
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Sync error:', err);
    res.status(500).json({ error: err.message });
  }
}

function mapCategory(smmCategory) {
  const categoryMap = {
    'Instagram Followers': 'instagram',
    'Instagram Likes': 'instagram',
    'Instagram Views': 'instagram',
    'Instagram Comments': 'instagram',
    'Instagram': 'instagram',
    'Twitter Followers': 'twitter',
    'Twitter Likes': 'twitter',
    'Twitter Retweets': 'twitter',
    'Twitter Views': 'twitter',
    'Twitter': 'twitter',
    'TikTok Followers': 'tiktok',
    'TikTok Likes': 'tiktok',
    'TikTok Views': 'tiktok',
    'TikTok Shares': 'tiktok',
    'TikTok': 'tiktok',
    'YouTube Subscribers': 'youtube',
    'YouTube Views': 'youtube',
    'YouTube Likes': 'youtube',
    'YouTube': 'youtube',
    'Facebook Page Likes': 'facebook',
    'Facebook Post Likes': 'facebook',
    'Facebook Followers': 'facebook',
    'Facebook': 'facebook',
    'Telegram Followers': 'telegram',
    'Telegram Members': 'telegram',
    'Telegram Post Views': 'telegram',
    'Telegram': 'telegram'
  };
  
  // Try to find matching category
  for (const [key, value] of Object.entries(categoryMap)) {
    if (smmCategory?.toLowerCase().includes(key.toLowerCase())) {
      return value;
    }
  }
  
  // Default to 'other' if no match
  return 'instagram'; // Default to Instagram
}