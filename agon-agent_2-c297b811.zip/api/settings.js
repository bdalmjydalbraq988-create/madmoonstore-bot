import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { data: settings } = await supabase
        .from('settings')
        .select('*')
        .single();
      
      return res.status(200).json(settings || {
        profit_margin: 20,
        auto_dispatch: true,
        auto_check_status: true,
        currency: 'USD'
      });
    }
    
    if (req.method === 'POST') {
      const updates = req.body;
      
      const { data: existing } = await supabase
        .from('settings')
        .select('*')
        .single();
      
      if (existing) {
        const { data: settings } = await supabase
          .from('settings')
          .update(updates)
          .select()
          .single();
        return res.status(200).json(settings);
      } else {
        const { data: settings } = await supabase
          .from('settings')
          .insert(updates)
          .select()
          .single();
        return res.status(201).json(settings);
      }
    }
    
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Settings error:', err);
    res.status(500).json({ error: err.message });
  }
}