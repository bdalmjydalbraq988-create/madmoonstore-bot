import supabase from './_supabase.js';
import { createOrder } from './smm.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'POST') {
      const { orderId } = req.body;
      
      // Get order details
      const { data: order, error: orderError } = await supabase
        .from('orders')
        .select('*')
        .eq('id', orderId)
        .single();
      
      if (orderError || !order) {
        return res.status(404).json({ error: 'Order not found' });
      }
      
      if (order.status !== 'pending') {
        return res.status(400).json({ error: 'Order is not in pending status' });
      }
      
      // Get service details to get SMM service ID
      const { data: service } = await supabase
        .from('services')
        .select('smm_service_id')
        .eq('id', order.service_id)
        .single();
      
      if (!service || !service.smm_service_id) {
        return res.status(400).json({ error: 'Service not linked to SMM provider' });
      }
      
      // Create order with SMM provider
      const smmOrder = await createOrder(
        service.smm_service_id,
        order.link,
        order.quantity
      );
      
      // Update order with SMM order ID
      await supabase
        .from('orders')
        .update({
          smm_order_id: smmOrder.order,
          status: 'processing',
          smm_response: JSON.stringify(smmOrder)
        })
        .eq('id', orderId);
      
      return res.status(200).json({
        success: true,
        smmOrderId: smmOrder.order,
        message: 'Order dispatched to SMM provider'
      });
    }
    
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Dispatch error:', err);
    res.status(500).json({ error: err.message });
  }
}