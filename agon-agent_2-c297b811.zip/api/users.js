import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { telegram_id } = req.query;
      
      if (telegram_id) {
        const { data, error } = await supabase
          .from('users')
          .select('*')
          .eq('telegram_id', telegram_id)
          .single();
        if (error && error.code !== 'PGRST116') throw error;
        return res.status(200).json(data || null);
      }
      
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .order('balance', { ascending: false });
      if (error) throw error;
      return res.status(200).json(data);
    }
    
    if (req.method === 'POST') {
      const { telegram_id, username, first_name } = req.body;
      
      // Check if user exists
      const { data: existing } = await supabase
        .from('users')
        .select('*')
        .eq('telegram_id', telegram_id)
        .single();
      
      if (existing) {
        return res.status(200).json(existing);
      }
      
      const { data, error } = await supabase
        .from('users')
        .insert({
          telegram_id,
          username,
          first_name,
          balance: 0
        })
        .select()
        .single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    
    if (req.method === 'PUT') {
      const { telegram_id, balance } = req.body;
      const { data, error } = await supabase
        .from('users')
        .update({ balance })
        .eq('telegram_id', telegram_id)
        .select()
        .single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}