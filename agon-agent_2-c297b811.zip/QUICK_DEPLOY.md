# 🚀 نشر سريع على Netlify - 3 خطوات فقط!

## الخطوة 1: إنشاء حساب Netlify (دقيقة واحدة)

1. اذهب إلى: https://app.netlify.com/signup
2. سجل حساباً جديداً (مجاني)
3. اضغط "Add new site" → "Deploy manually"
4. اسحب وأفلت مجلد المشروع بالكامل
5. اضغط "Deploy site"

---

## الخطوة 2: إضافة متغيرات البيئة (دقيقتان)

اذهب إلى: Site settings → Environment variables

أضف المتغيرات التالية (انسخها كما هي):

```
NEXT_PUBLIC_SUPABASE_URL=https://zdjzdgxwhtjedknrzxmx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=sb_publishable_VGUQhIqd0T6kN-PVN8I1gw_W7ZYO3-B
SUPABASE_SERVICE_ROLE_KEY=sb_secret_Yg6OV3hl7Ie1fYN0xuebcQ_nIsnBu4p
VITE_SUPABASE_URL=https://zdjzdgxwhtjedknrzxmx.supabase.co
VITE_SUPABASE_ANON_KEY=sb_publishable_VGUQhIqd0T6kN-PVN8I1gw_W7ZYO3-B
TELEGRAM_BOT_TOKEN=8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU
SMM_API_URL=https://smmsharks.com/api/v2
SMM_API_KEY=01b815347b66b2fe9527d631b98bbb3a
```

---

## الخطوة 3: تفعيل البوت (دقيقة واحدة)

استبدل `YOUR_SITE_URL` برابط موقعك الفعلي:

```bash
curl -F "url=https://YOUR_SITE_URL.netlify.app/api/telegram" \
  https://api.telegram.org/bot8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU/setWebhook
```

**مثال:**
```bash
curl -F "url=https://madmoonstore-bot.netlify.app/api/telegram" \
  https://api.telegram.org/bot8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU/setWebhook
```

---

## ✅ تم! البوت جاهز الآن!

### اختبر البوت:
1. افتح تيليجرام
2. ابحث عن: @MadmoonStore_bot
3. اكتب: `/start`
4. جرب الخدمات!

### لوحة التحكم:
```
https://YOUR_SITE_URL.netlify.app/dashboard
```

---

## 📞 واجهت مشكلة؟

### تحقق من السجلات:
1. اذهب إلى Netlify Dashboard
2. اختر موقعك
3. اضغط "Functions" → "View logs"

### أعد النشر:
1. اضغط "Deploys" → "Trigger deploy"
2. اضغط "Deploy site"

---

## 🎉 مبروك! استمتع بالأرباح!
