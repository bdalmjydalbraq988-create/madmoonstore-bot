# 🚀 البدء السريع - MadmoonStore Bot

## ⚡ الطريقة الأسرع (5 دقائق):

### 1. تحميل الملف
```
اختر: madmoonstore-lite.tar.gz (28MB)
```

### 2. فك الضغط
- استخرج الملفات على جهازك

### 3. الرفع على Netlify
1. اذهب إلى: https://app.netlify.com/drop
2. اسحب المجلد وأفلته
3. انتظر النشر (1-2 دقيقة)
4. انسخ الرابط

### 4. إضافة المتغيرات
1. اذهب إلى: Site settings → Environment variables
2. أضف:
```
TELEGRAM_BOT_TOKEN = 8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU
SMM_API_URL = https://smmsharks.com/api/v2
SMM_API_KEY = 01b815347b66b2fe9527d631b98bbb3a
NEXT_PUBLIC_SUPABASE_URL = https://zdjzdgxwhtjedknrzxmx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY = sb_publishable_VGUQhIqd0T6kN-PVN8I1gw_W7ZYO3-B
SUPABASE_SERVICE_ROLE_KEY = sb_secret_Yg6OV3hl7Ie1fYN0xuebcQ_nIsnBu4p
VITE_SUPABASE_URL = https://zdjzdgxwhtjedknrzxmx.supabase.co
VITE_SUPABASE_ANON_KEY = sb_publishable_VGUQhIqd0T6kN-PVN8I1gw_W7ZYO3-B
```

### 5. إعداد Webhook
استبدل `YOUR_SITE_URL` برابط موقعك:
```bash
curl -F "url=https://YOUR_SITE_URL.netlify.app/api/telegram" \
  https://api.telegram.org/bot8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU/setWebhook
```

### 6. ابدأ!
افتح تيليجرام واكتب `/start` في @MadmoonStore_bot

---

## ✅ تم! البوت يعمل الآن!

### روابط مهمة:
- الموقع: `https://YOUR_SITE_URL.netlify.app`
- لوحة التحكم: `https://YOUR_SITE_URL.netlify.app/dashboard`
- البوت: @MadmoonStore_bot

---

## 💡 نصائح:

1. **ابدأ بمزامنة الخدمات:**
   - اذهب إلى /services
   - اضغط "مزامنة من SMM"

2. **شحن أرصدة:**
   - اذهب إلى /users
   - شحن أرصدة للعملاء

3. **راقب الطلبات:**
   - اذهب إلى /orders
   - راقب الطلبات القادمة

---

## 🎉 مبروك! ابدأ في كسب الأرباح!
