# 🚀 نشر المشروع على Netlify

## الخطوات التفصيلية:

### الطريقة الأولى: عبر موقع Netlify (الأسهل)

#### 1️⃣ إنشاء حساب Netlify
- اذهب إلى: https://app.netlify.com/signup
- سجل حساباً جديداً (مجاني)

#### 2️⃣ ربط المشروع مع GitHub
1. بعد تسجيل الدخول، اضغط "Add new site" → "Import an existing project"
2. اختر "GitHub" واسمح بالوصول
3. ابحث عن مستودع المشروع (أو ارفع الملفات يدوياً)

#### 3️⃣ إعدادات البناء
```
Build command: npm run build
Publish directory: dist
```

#### 4️⃣ إضافة متغيرات البيئة
اذهب إلى: Site settings → Environment variables

أضف المتغيرات التالية:
```
NEXT_PUBLIC_SUPABASE_URL = https://zdjzdgxwhtjedknrzxmx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY = sb_publishable_VGUQhIqd0T6kN-PVN8I1gw_W7ZYO3-B
SUPABASE_SERVICE_ROLE_KEY = sb_secret_Yg6OV3hl7Ie1fYN0xuebcQ_nIsnBu4p
VITE_SUPABASE_URL = https://zdjzdgxwhtjedknrzxmx.supabase.co
VITE_SUPABASE_ANON_KEY = sb_publishable_VGUQhIqd0T6kN-PVN8I1gw_W7ZYO3-B
TELEGRAM_BOT_TOKEN = 8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU
SMM_API_URL = https://smmsharks.com/api/v2
SMM_API_KEY = 01b815347b66b2fe9527d631b98bbb3a
```

#### 5️⃣ اضغط "Deploy site"

---

### الطريقة الثانية: عبر Netlify CLI (أسرع)

#### 1️⃣ تثبيت Netlify CLI
```bash
npm install -g netlify-cli
```

#### 2️⃣ تسجيل الدخول
```bash
netlify login
```

#### 3️⃣ تهيئة المشروع
```bash
netlify init
```
- اختر "Create & configure a new site"
- اختر فريقك
- أدخل اسم الموقع: `madmoonstore-bot`

#### 4️⃣ النشر
```bash
netlify deploy --prod
```

---

## بعد النشر:

### 1️⃣ الحصول على رابط الموقع
- سيظهر رابط مثل: `https://madmoonstore-bot.netlify.app`

### 2️⃣ إعداد Webhook للبوت
استبدل `YOUR_SITE_URL` برابط موقعك:

```bash
curl -F "url=https://YOUR_SITE_URL.netlify.app/api/telegram" \
  https://api.telegram.org/bot8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU/setWebhook
```

### 3️⃣ اختبار البوت
1. افتح تيليجرام
2. ابحث عن @MadmoonStore_bot
3. اكتب `/start`
4. جرب الخدمات!

---

## 🎯 روابط مهمة:

- **لوحة التحكم:** `https://YOUR_SITE_URL.netlify.app/dashboard`
- **الخدمات:** `https://YOUR_SITE_URL.netlify.app/services`
- **الطلبات:** `https://YOUR_SITE_URL.netlify.app/orders`
- **المستخدمين:** `https://YOUR_SITE_URL.netlify.app/users`
- **الإعدادات:** `https://YOUR_SITE_URL.netlify.app/settings`

---

## ✅ التحقق من النشر:

### اختبار API:
```bash
curl https://YOUR_SITE_URL.netlify.app/api/services
```

### اختبار Webhook:
```bash
curl https://api.telegram.org/bot8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU/getWebhookInfo
```

---

## 📞 إذا واجهت مشاكل:

1. **تحقق من السجلات:**
   - اذهب إلى Netlify Dashboard
   - اختر موقعك
   - اضغط "Functions" → "View logs"

2. **تأكد من متغيرات البيئة:**
   - Site settings → Environment variables

3. **أعد النشر:**
   - اضغط "Deploys" → "Trigger deploy" → "Deploy site"

---

## 🎉 مبروك! البوت جاهز للاستخدام!
