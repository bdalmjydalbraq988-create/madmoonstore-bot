# 📥 دليل تحميل ونشر MadmoonStore Bot

## 📦 الملفات المتاحة:

### 1️⃣ madmoonstore-bot.tar.gz (72KB) - الأسرع ⭐
**المحتوى:** الملفات الأساسية فقط (src, api, package.json, إلخ)
**الحجم:** صغير جداً
**لمن:** المستخدمين المتقدمين
**الميزة:** أسرع في الرفع والتنزيل

### 2️⃣ madmoonstore-lite.tar.gz (28MB) - الأنسب 🎯
**المحتوى:** جميع الملفات بدون node_modules
**الحجم:** متوسط
**لمن:** معظم المستخدمين
**الميزة:** Netlify سيقوم بتثبيت node_modules تلقائياً

### 3️⃣ madmoonstore-full.tar.gz (56MB) - الكامل
**المحتوى:** جميع الملفات مع node_modules
**الحجم:** كبير
**لمن:** المستخدمين الذين يريدون كل شيء جاهز
**الميزة:** لا يحتاج لتثبيت أي شيء

---

## 🚀 كيفية النشر على Netlify:

### الطريقة الأولى: رفع الملفات يدوياً (الأسهل)

#### الخطوة 1: تحميل الملف
```
اختر أحد الملفات:
- madmoonstore-bot.tar.gz (72KB) - للأسرع
- madmoonstore-lite.tar.gz (28MB) - الأنسب
- madmoonstore-full.tar.gz (56MB) - الكامل
```

#### الخطوة 2: فك الضغط
1. فك الضغط على جهازك
2. ستحصل على مجلد يحتوي على جميع الملفات

#### الخطوة 3: الرفع على Netlify
1. اذهب إلى: https://app.netlify.com/drop
2. اسحب وأفلت المجلد الذي فككت ضغطه
3. انتظر حتى ينتهي النشر
4. ستحصل على رابط مثل: `https://random-name.netlify.app`

#### الخطوة 4: إضافة متغيرات البيئة
1. اذهب إلى: Site settings → Environment variables
2. أضف المتغيرات التالية:

```
NEXT_PUBLIC_SUPABASE_URL = https://zdjzdgxwhtjedknrzxmx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY = sb_publishable_VGUQhIqd0T6kN-PVN8I1gw_W7ZYO3-B
SUPABASE_SERVICE_ROLE_KEY = sb_secret_Yg6OV3hl7Ie1fYN0xuebcQ_nIsnBu4p
VITE_SUPABASE_URL = https://zdjzdgxwhtjedknrzxmx.supabase.co
VITE_SUPABASE_ANON_KEY = sb_publishable_VGUQhIqd0T6kN-PVN8I1gw_W7ZYO3-B
TELEGRAM_BOT_TOKEN = 8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU
SMM_API_URL = https://smmsharks.com/api/v2
SMM_API_KEY = 01b815347b66b2fe9527d631b98bbb3a
```

#### الخطوة 5: إعداد Webhook للبوت
استبدل `YOUR_SITE_URL` برابط موقعك الجديد:

```bash
curl -F "url=https://YOUR_SITE_URL.netlify.app/api/telegram" \
  https://api.telegram.org/bot8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU/setWebhook
```

---

### الطريقة الثانية: عبر GitHub (الموصى به) ⭐

#### الخطوة 1: إنشاء مستودع GitHub
1. اذهب إلى: https://github.com/new
2. أدخل اسم: `madmoonstore-bot`
3. اضغط "Create repository"

#### الخطوة 2: رفع الملفات
**أ) إذا كنت تستخدم Git:**
```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR_USERNAME/madmoonstore-bot.git
git push -u origin main
```

**ب) إذا كنت تريد الرفع يدوياً:**
1. فك ضغط الملف
2. افتح المجلد
3. افتح GitHub.com
4. اضغط "Upload files"
5. اسحب وأفلت جميع الملفات
6. اضغط "Commit changes"

#### الخطوة 3: الربط مع Netlify
1. اذهب إلى: https://app.netlify.com/start
2. اختر "GitHub"
3. اسمح بالوصول
4. اختر مستودع `madmoonstore-bot`
5. اضغط "Deploy site"

#### الخطوة 4: إضافة متغيرات البيئة
1. بعد النشر، اذهب إلى: Site settings → Environment variables
2. أضف نفس المتغيرات المذكورة أعلاه

---

## ✅ بعد النشر:

### 1. الحصول على رابط الموقع
- سيظهر في لوحة تحكم Netlify
- أو في الـ Terminal بعد النشر

### 2. اختبار الموقع
افتح الرابط في المتصفح:
```
https://YOUR_SITE_URL.netlify.app
```

### 3. إعداد Webhook
```bash
curl -F "url=https://YOUR_SITE_URL.netlify.app/api/telegram" \
  https://api.telegram.org/bot8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU/setWebhook
```

### 4. اختبار البوت
1. افتح تيليجرام
2. ابحث عن @MadmoonStore_bot
3. اكتب `/start`
4. جرب الخدمات!

---

## 🎯 روابط لوحة التحكم:

بعد النشر، استخدم هذه الروابط:

- **الرئيسية:** `https://YOUR_SITE_URL.netlify.app/`
- **لوحة التحكم:** `https://YOUR_SITE_URL.netlify.app/dashboard`
- **الخدمات:** `https://YOUR_SITE_URL.netlify.app/services`
- **الطلبات:** `https://YOUR_SITE_URL.netlify.app/orders`
- **المستخدمين:** `https://YOUR_SITE_URL.netlify.app/users`
- **الإعدادات:** `https://YOUR_SITE_URL.netlify.app/settings`

---

## 📞 الدعم:

إذا واجهت أي مشكلة:

1. **تحقق من السجلات:**
   - Netlify Dashboard → Site → Functions → View logs

2. **تأكد من متغيرات البيئة:**
   - Site settings → Environment variables

3. **أعد النشر:**
   - Deploys → Trigger deploy → Deploy site

---

## 🎉 مبروك!

الآن لديك بوت تيليجرام متكامل مع:
- ✅ موقع ويب احترافي
- ✅ لوحة تحكم متقدمة
- ✅ ربط مع SMM Sharks
- ✅ قاعدة بيانات كاملة
- ✅ نظام إدارة شامل

ابدأ في كسب الأرباح! 💰
