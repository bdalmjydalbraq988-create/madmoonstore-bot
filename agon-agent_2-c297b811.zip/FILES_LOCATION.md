# 📦 موقع ملفات المشروع

## 📍 أين توجد الملفات؟

الملفات المضغوطة موجودة في المجلد التالي:
```
/tmp/
```

## 📋 الملفات المتاحة:

### 1️⃣ madmoonstore-lite.tar.gz (28MB) - الأنسب 🎯
**المسار:** `/tmp/madmoonstore-lite.tar.gz`
**الحجم:** 28MB
**يحتوي على:** جميع الملفات بدون node_modules
**لماذا هذا الملف؟** Netlify سيقوم بتثبيت node_modules تلقائياً

### 2️⃣ madmoonstore-full.tar.gz (56MB) - الكامل
**المسار:** `/tmp/madmoonstore-full.tar.gz`
**الحجم:** 56MB
**يحتوي على:** جميع الملفات مع node_modules
**لماذا هذا الملف؟** جاهز بالكامل، لا يحتاج لتثبيت أي شيء

---

## 🚀 كيفية التحميل والنشر:

### الطريقة الأولى: عبر واجهة المستخدم (الأسهل)

#### الخطوة 1: تحميل الملف
1. افتح مدير الملفات
2. انتقل إلى المجلد `/tmp/`
3. ابحث عن الملفات:
   - `madmoonstore-lite.tar.gz` (28MB) - أنصح بهذا
   - `madmoonstore-full.tar.gz` (56MB) - إذا أردت كل شيء جاهز
4. انسخ الملف إلى سطح المكتب أو مجلد مريح لك

#### الخطوة 2: فك الضغط
1. انقر بزر الماوس الأيمن على الملف
2. اختر "Extract Here" أو "استخراج هنا"
3. انتظر حتى ينتهي فك الضغط
4. ستحصل على مجلد باسم `madmoonstore-bot` أو مشابه

#### الخطوة 3: الرفع على Netlify
1. افتح المتصفح
2. اذهب إلى: https://app.netlify.com/drop
3. اسحب المجلد المستخرج وأفلته في المنطقة المخصصة
4. انتظر حتى ينتهي النشر (1-2 دقيقة)
5. ستحصل على رابط مثل: `https://random-name.netlify.app`

#### الخطوة 4: إضافة متغيرات البيئة
1. في لوحة تحكم Netlify، اذهب إلى: Site settings → Environment variables
2. اضغط "Add new variable"
3. أضف المتغيرات التالية واحداً تلو الآخر:

```
TELEGRAM_BOT_TOKEN = 8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU
SMM_API_URL = https://smmsharks.com/api/v2
SMM_API_KEY = 01b815347b66b2fe9527d631b98bbb3a
NEXT_PUBLIC_SUPABASE_URL = https://zdjzdgxwhtjedknrzxmx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY = sb_publishable_VGUQhIqd0T6kN-PVN8I1gw_W7ZYO3-B
SUPABASE_SERVICE_ROLE_KEY = sb_secret_Yg6OV3hl7Ie1fYN0xuebcQ_nIsnBu4p
VITE_SUPABASE_URL = https://zdjzdgxwhtjedknrzxmx.supabase.co
VITE_SUPABASE_ANON_KEY = sb_publishable_VGUQhIqd0T6kN-PVN8I1gw_W7ZYO3-B
```

#### الخطوة 5: إعداد Webhook للبوت
استبدل `YOUR_SITE_URL` برابط موقعك الجديد:

**على Linux/Mac:**
```bash
curl -F "url=https://YOUR_SITE_URL.netlify.app/api/telegram" \
  https://api.telegram.org/bot8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU/setWebhook
```

**على Windows (PowerShell):**
```powershell
curl.exe -F "url=https://YOUR_SITE_URL.netlify.app/api/telegram" `
  https://api.telegram.org/bot8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU/setWebhook
```

#### الخطوة 6: اختبار البوت
1. افتح تيليجرام
2. ابحث عن @MadmoonStore_bot
3. اكتب `/start`
4. جرب الخدمات!

---

### الطريقة الثانية: عبر GitHub (الموصى به للمطورين)

#### الخطوة 1: إنشاء مستودع GitHub
1. اذهب إلى: https://github.com/new
2. أدخل اسم المستودع: `madmoonstore-bot`
3. اضغط "Create repository"

#### الخطوة 2: رفع الملفات
**أ) إذا كنت تستخدم Git:**
```bash
# انتقل إلى المجلد المستخرج
cd madmoonstore-bot

# تهيئة Git
git init
git add .
git commit -m "Initial commit"

# ربط المستودع
git remote add origin https://github.com/YOUR_USERNAME/madmoonstore-bot.git

# رفع الملفات
git push -u origin main
```

**ب) إذا كنت تريد الرفع يدوياً:**
1. افتح GitHub.com
2. اذهب إلى المستودع الذي أنشأته
3. اضغط "Upload files"
4. افتح المجلد المستخرج
5. اسحب جميع الملفات وأفلها
6. اضغط "Commit changes"

#### الخطوة 3: الربط مع Netlify
1. اذهب إلى: https://app.netlify.com/start
2. اختر "GitHub"
3. اسمح بالوصول إلى حسابك
4. اختر مستودع `madmoonstore-bot`
5. اضغط "Deploy site"
6. انتظر النشر

#### الخطوة 4: إضافة متغيرات البيئة
نفس الخطوات المذكورة في الطريقة الأولى

---

## ✅ بعد النشر:

### 1. الحصول على رابط الموقع
- سيظهر في لوحة تحكم Netlify
- شكل الرابط: `https://your-site-name.netlify.app`

### 2. اختبار الموقع
افتح الرابط في المتصفح:
```
https://your-site-name.netlify.app
```

### 3. اختبار البوت
1. افتح تيليجرام
2. ابحث عن @MadmoonStore_bot
3. اكتب `/start`
4. جرب الخدمات!

---

## 🎯 روابط مهمة بعد النشر:

بعد النشر، استخدم هذه الروابط:

- **الرئيسية:** `https://your-site-name.netlify.app/`
- **لوحة التحكم:** `https://your-site-name.netlify.app/dashboard`
- **الخدمات:** `https://your-site-name.netlify.app/services`
- **الطلبات:** `https://your-site-name.netlify.app/orders`
- **المستخدمين:** `https://your-site-name.netlify.app/users`
- **الإعدادات:** `https://your-site-name.netlify.app/settings`

---

## 📞 إذا واجهت مشاكل:

### المشكلة 1: الملفات لا توجد في /tmp/
**الحل:** الملفات موجودة في بيئة العمل الحالية. يمكنك:
1. نسخ الملفات من المشروع الحالي
2. أو استخدام GitHub لرفع المشروع

### المشكلة 2: فشل النشر على Netlify
**الحل:**
1. تحقق من أن جميع الملفات موجودة
2. تأكد من وجود `package.json`
3. راجع سجلات النشر في Netlify

### المشكلة 3: البوت لا يعمل
**الحل:**
1. تأكد من إضافة `TELEGRAM_BOT_TOKEN` في متغيرات البيئة
2. تحقق من إعداد Webhook
3. راجع سجلات Functions في Netlify

---

## 🎉 مبروك!

الآن لديك كل ما تحتاجه لنشر البوت!

ابدأ في كسب الأرباح! 💰
