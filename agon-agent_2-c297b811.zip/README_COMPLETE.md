# 🤖 MadmoonStore Bot - نظام متكامل لخدمات SMM

## 📋 المحتويات:
- [نظرة عامة](#نظرة-عامة)
- [المميزات](#المميزات)
- [التثبيت](#التثبيت)
- [النشر على Netlify](#النشر-على-netlify)
- [التشغيل المحلي](#التشغيل-المحلي)
- [الاستخدام](#الاستخدام)
- [الإعدادات](#الإعدادات)
- [الدعم](#الدعم)

---

## 🎯 نظرة عامة

نظام متكامل لبيع خدمات التواصل الاجتماعي (SMM) مع:
- ✅ بوت تيليجرام آلي
- ✅ لوحة تحكم إدارية
- ✅ ربط مع مزود SMM (SMM Sharks)
- ✅ قاعدة بيانات كاملة
- ✅ نظام إدارة الطلبات
- ✅ شحن أرصدة للمستخدمين

---

## ✨ المميزات

### للعملاء:
- 🤖 بوت تيليجرام سهل الاستخدام
- 🛒 طلب خدمات بضغطة زر
- 📊 تتبع الطلبات في الوقت الفعلي
- 💰 إدارة الرصيد

### للمسؤولين:
- 📈 لوحة تحكم شاملة
- 🔄 مزامنة تلقائية للخدمات من SMM
- 💵 تعديل هامش الربح
- 👥 إدارة المستخدمين وأرصدتهم
- 📊 إحصائيات وتقارير

---

## 🚀 التثبيت

### المتطلبات:
- Node.js 18 أو أحدث
- npm أو yarn
- حساب على Supabase
- حساب على SMM Sharks

### الخطوات:

1. **استنساخ المشروع:**
```bash
git clone <repository-url>
cd madmoonstore-bot
```

2. **تثبيت المكتبات:**
```bash
npm install
```

3. **إعداد متغيرات البيئة:**
أنشئ ملف `.env` وأضف:
```
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_supabase_service_key
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
TELEGRAM_BOT_TOKEN=your_bot_token
SMM_API_URL=https://smmsharks.com/api/v2
SMM_API_KEY=your_smm_api_key
```

---

## 🌐 النشر على Netlify

### الطريقة السريعة (5 دقائق):

1. **ادخل على Netlify:**
   ```
   https://app.netlify.com
   ```

2. **ارفع المشروع:**
   - اضغط "Add new site"
   - اختر "Deploy manually"
   - ارفع مجلد المشروع بالكامل

3. **أضف متغيرات البيئة:**
   - Site settings → Environment variables
   - أضف المتغيرات المذكورة أعلاه

4. **أعد نشر الموقع:**
   - Deploys → Trigger deploy

5. **إعداد Webhook للبوت:**
```bash
curl -F "url=https://your-site.netlify.app/api/telegram" \
  https://api.telegram.org/botYOUR_BOT_TOKEN/setWebhook
```

### التفاصيل الكاملة:
راجع ملف `DEPLOY_GUIDE.md`

---

## 💻 التشغيل المحلي

### 1️⃣ تثبيت المكتبات:
```bash
npm install
```

### 2️⃣ إنشاء ملف .env:
راجع قسم "التثبيت" أعلاه

### 3️⃣ تشغيل المشروع:
```bash
npm run dev
```

### 4️⃣ فتح الموقع:
```
http://localhost:5173
```

### التفاصيل الكاملة:
راجع ملف `LOCAL_SETUP.md`

---

## 📱 الاستخدام

### للعملاء (من البوت):

1. **ابدأ البوت:**
   ```
   ابحث عن @MadmoonStore_bot
   اكتب /start
   ```

2. **اختر خدمة:**
   - اضغط "🛒 طلب خدمة"
   - اختر المنصة
   - اختر الخدمة

3. **أدخل البيانات:**
   - الرابط
   - الكمية
   - تأكيد

4. **تتبع الطلب:**
   - اضغط "📊 طلباتي"

### للمسؤولين (من الموقع):

#### 1. الدخول للوحة التحكم:
```
https://your-site.netlify.app/dashboard
```

#### 2. مزامنة الخدمات:
- اذهب إلى "الخدمات"
- اضغط "مزامنة من SMM"

#### 3. إدارة الطلبات:
- اذهب إلى "الطلبات"
- اعرض وأدير جميع الطلبات

#### 4. شحن أرصدة:
- اذهب إلى "المستخدمين"
- ابحث عن المستخدم
- شحن الرصيد

#### 5. تعديل الإعدادات:
- اذهب إلى "الإعدادات"
- عدّل هامش الربح
- حفظ التغييرات

---

## ⚙️ الإعدادات

### هامش الربح:
- الافتراضي: 20%
- يمكن تعديله من صفحة الإعدادات
- يتم تطبيقه عند مزامنة الخدمات

### التنفيذ التلقائي:
- مفعل افتراضياً
- يرسل الطلبات تلقائياً لـ SMM
- يمكن تعطيله من الإعدادات

### فحص الحالة:
- مفعل افتراضياً
- يحدث حالة الطلبات من SMM
- يمكن تعطيله من الإعدادات

---

## 📊 قاعدة البيانات

### الجداول:

#### services:
- id
- name
- category
- price_per_1000
- min_order
- max_order
- description
- smm_service_id
- original_price

#### orders:
- id
- service_id
- service_name
- telegram_id
- telegram_username
- link
- quantity
- completed_quantity
- total_price
- status
- smm_order_id
- created_at

#### users:
- id
- telegram_id
- username
- first_name
- balance
- created_at

#### settings:
- id
- profit_margin
- auto_dispatch
- auto_check_status
- currency
- smm_api_url
- smm_api_key
- bot_token
- bot_username

---

## 🔧 API Endpoints

### الخدمات:
- `GET /api/services` - جلب جميع الخدمات
- `POST /api/services` - إضافة خدمة جديدة
- `PUT /api/services` - تعديل خدمة
- `DELETE /api/services` - حذف خدمة
- `POST /api/sync-services` - مزامنة من SMM

### الطلبات:
- `GET /api/orders` - جلب جميع الطلبات
- `POST /api/telegram-order` - إنشاء طلب جديد
- `PUT /api/orders` - تحديث طلب
- `POST /api/dispatch-order` - إرسال لـ SMM
- `POST /api/check-status` - فحص الحالة من SMM

### المستخدمين:
- `GET /api/users` - جلب جميع المستخدمين
- `GET /api/users?telegram_id=X` - جلب مستخدم محدد
- `POST /api/users` - إنشاء مستخدم جديد
- `PUT /api/users` - تحديث مستخدم

### الإحصائيات:
- `GET /api/stats` - جلب الإحصائيات

### الإعدادات:
- `GET /api/settings` - جلب الإعدادات
- `POST /api/settings` - تحديث الإعدادات

### SMM:
- `GET /api/smm-balance` - جلب رصيد SMM

---

## 🤖 بوت تيليجرام

### الأوامر:
- `/start` - بدء البوت
- `/help` - المساعدة

### الأزرار التفاعلية:
- 🛒 طلب خدمة
- 📊 طلباتي
- 💰 رصيدي
- 📞 دعم فني

---

## 📞 الدعم

### المشاكل الشائعة:

#### البوت لا يستجيب:
1. تحقق من Webhook:
```bash
curl https://api.telegram.org/botYOUR_TOKEN/getWebhookInfo
```

2. أعد تعيين Webhook:
```bash
curl -F "url=https://your-site.netlify.app/api/telegram" \
  https://api.telegram.org/botYOUR_TOKEN/setWebhook
```

#### API لا يعمل:
1. تحقق من السجلات في Netlify
2. تأكد من متغيرات البيئة
3. أعد نشر الموقع

#### الطلبات لا تُنفذ:
1. تحقق من رصيد SMM
2. تأكد من أن الخدمة مرتبطة بـ SMM
3. تحقق من حالة الطلب

---

## 📝 الترخيص

هذا المشروع مفتوح المصدر للاستخدام الشخصي والتجاري.

---

## 🎉 شكراً لاستخدام MadmoonStore Bot!

للدعم والمساعدة، تواصل معنا عبر:
- تيليجرام: @support
- إيميل: support@madmoonstore.com
