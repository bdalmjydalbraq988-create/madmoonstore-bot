# 🚀 دليل النشر السريع - Netlify

## ⚡ الطريقة السريعة (5 دقائق)

### 1️⃣ ادخل على Netlify
```
https://app.netlify.com
```

### 2️⃣ اضغط "Add new site"

### 3️⃣ اختر "Deploy manually"

### 4️⃣ ارفع مجلد المشروع بالكامل (drag & drop)
   - انتظر حتى ينتهي الرفع والبناء

### 5️⃣ بعد النشر، اذهب إلى:
   Site settings → Environment variables

### 6️⃣ أضف هذه المتغيرات:

```
NEXT_PUBLIC_SUPABASE_URL = https://zdjzdgxwhtjedknrzxmx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY = sb_publishable_VGUQhIqd0T6kN-PVN8I1gw_W7ZYO3-B
SUPABASE_SERVICE_ROLE_KEY = sb_secret_Yg6OV3hl7Ie1fYN0xuebcQ_nIsnBu4p
VITE_SUPABASE_URL = https://zdjzdgxwhtjedknrzxmx.supabase.co
VITE_SUPABASE_ANON_KEY = sb_publishable_VGUQhIqd0T6kN-PVN8I1gw_W7ZYO3-B
TELEGRAM_BOT_TOKEN = 8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU
SMM_API_URL = https://smmsharks.com/api/v2
SMM_API_KEY = 01b815347b66b2fe9527d631b98bbb3a
```

### 7️⃣ أعد نشر الموقع
   Deploys → Trigger deploy → Deploy site

### 8️⃣ احصل على رابط موقعك
   سيظهر مثل: `https://your-site-name.netlify.app`

### 9️⃣ إعداد Webhook للبوت
استبدل `your-site-name` برابط موقعك الفعلي:

```bash
curl -F "url=https://your-site-name.netlify.app/api/telegram" \
  https://api.telegram.org/bot8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU/setWebhook
```

### 🔟 اختبر البوت
1. افتح تيليجرام
2. ابحث عن @MadmoonStore_bot
3. اكتب `/start`

---

## ✅ تم! البوت يعمل الآن!

### روابط لوحة التحكم:
- الرئيسية: `https://your-site-name.netlify.app`
- لوحة التحكم: `https://your-site-name.netlify.app/dashboard`
- الخدمات: `https://your-site-name.netlify.app/services`
- الطلبات: `https://your-site-name.netlify.app/orders`
- المستخدمين: `https://your-site-name.netlify.app/users`
- الإعدادات: `https://your-site-name.netlify.app/settings`

---

## 🎯 الخطوات التالية:

1. **مزامنة الخدمات:**
   - اذهب إلى الخدمات
   - اضغط "مزامنة من SMM"

2. **شحن أرصدة:**
   - اذهب إلى المستخدمين
   - شحن أرصدة للعملاء

3. **ابدأ التسويق:**
   - شارك رابط البوت: @MadmoonStore_bot
   - شارك رابط الموقع مع العملاء

---

## 📞 إذا واجهت مشاكل:

### تحقق من السجلات:
Netlify Dashboard → Your Site → Functions → View logs

### تحقق من Webhook:
```bash
curl https://api.telegram.org/bot8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU/getWebhookInfo
```

---

## 🎊 مبروك! نظامك جاهز للاستخدام! 🚀
