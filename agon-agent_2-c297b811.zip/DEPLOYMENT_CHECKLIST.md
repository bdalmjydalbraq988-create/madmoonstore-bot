# ✅ قائمة التحقق قبل النشر

## 📋 الملفات المطلوبة:

### ✅ ملفات API (16 ملف):
- [ ] `api/_supabase.js` - اتصال قاعدة البيانات
- [ ] `api/_wake.js` - إعادة استعادة قاعدة البيانات
- [ ] `api/telegram.js` - بوت تيليجرام
- [ ] `api/telegram-order.js` - إنشاء الطلبات
- [ ] `api/services.js` - إدارة الخدمات
- [ ] `api/orders.js` - إدارة الطلبات
- [ ] `api/users.js` - إدارة المستخدمين
- [ ] `api/stats.js` - الإحصائيات
- [ ] `api/settings.js` - الإعدادات
- [ ] `api/smm.js` - ربط SMM Sharks ⭐
- [ ] `api/sync-services.js` - مزامنة الخدمات ⭐
- [ ] `api/dispatch-order.js` - إرسال الطلبات ⭐
- [ ] `api/check-status.js` - فحص الحالة ⭐
- [ ] `api/smm-balance.js` - رصيد SMM ⭐
- [ ] `api/package.json` - تبعيات API

### ✅ صفحات React (7 صفحة):
- [ ] `src/pages/Home.tsx` - الصفحة الرئيسية
- [ ] `src/pages/Dashboard.tsx` - لوحة التحكم
- [ ] `src/pages/Services.tsx` - إدارة الخدمات
- [ ] `src/pages/Orders.tsx` - إدارة الطلبات
- [ ] `src/pages/Users.tsx` - إدارة المستخدمين
- [ ] `src/pages/Settings.tsx` - الإعدادات
- [ ] `src/components/Navbar.tsx` - شريط التنقل

### ✅ ملفات التكوين:
- [ ] `netlify.toml` - إعدادات Netlify
- [ ] `package.json` - تبعيات المشروع
- [ ] `vite.config.ts` - إعدادات Vite
- [ ] `tsconfig.json` - إعدادات TypeScript
- [ ] `index.html` - الصفحة الرئيسية
- [ ] `public/favicon.svg` - أيقونة الموقع

---

## 🔐 متغيرات البيئة المطلوبة:

### Supabase:
- [ ] `NEXT_PUBLIC_SUPABASE_URL`
- [ ] `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- [ ] `SUPABASE_SERVICE_ROLE_KEY`
- [ ] `VITE_SUPABASE_URL`
- [ ] `VITE_SUPABASE_ANON_KEY`

### Telegram Bot:
- [ ] `TELEGRAM_BOT_TOKEN` = `8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU`

### SMM Provider:
- [ ] `SMM_API_URL` = `https://smmsharks.com/api/v2`
- [ ] `SMM_API_KEY` = `01b815347b66b2fe9527d631b98bbb3a`

### اختياري:
- [ ] `VITE_GOOGLE_CLIENT_ID`
- [ ] `VITE_GOOGLE_AUTH_PROXY`
- [ ] `FULLSTACK_PROJECT_REF`
- [ ] `FULLSTACK_RESTORE_API_URL`

---

## 🧪 الاختبارات قبل النشر:

### 1️⃣ اختبار البناء المحلي:
```bash
npm run build
```
يجب أن يكتمل بدون أخطاء.

### 2️⃣ اختبار API محلياً:
```bash
npm run dev
```
ثم افتح:
- http://localhost:5173/api/services
- http://localhost:5173/api/stats
- http://localhost:5173/api/smm-balance

### 3️⃣ اختبار ربط SMM:
```bash
curl "https://smmsharks.com/api/v2?action=balance&key=01b815347b66b2fe9527d631b98bbb3a"
```
يجب أن ترى:
```json
{
  "balance": "6.9980441",
  "currency": "USD"
}
```

### 4️⃣ اختبار البوت:
```bash
curl -F "url=https://YOUR_SITE_URL.netlify.app/api/telegram" \
  https://api.telegram.org/bot8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU/setWebhook
```

---

## 📦 بعد النشر على Netlify:

### 1️⃣ اختبار الموقع:
- [ ] فتح الرابط الرئيسي
- [ ] فتح لوحة التحكم (/dashboard)
- [ ] فتح صفحة الخدمات (/services)
- [ ] فتح صفحة الطلبات (/orders)
- [ ] فتح صفحة المستخدمين (/users)
- [ ] فتح صفحة الإعدادات (/settings)

### 2️⃣ اختبار API:
- [ ] `/api/services` - عرض الخدمات
- [ ] `/api/orders` - عرض الطلبات
- [ ] `/api/users` - عرض المستخدمين
- [ ] `/api/stats` - عرض الإحصائيات
- [ ] `/api/smm-balance` - رصيد SMM

### 3️⃣ اختبار مزامنة الخدمات:
- [ ] اذهب إلى صفحة الخدمات
- [ ] اضغط "مزامنة من SMM"
- [ ] تأكد من ظهور رسالة نجاح
- [ ] تأكد من تحديث قائمة الخدمات

### 4️⃣ اختبار البوت:
- [ ] افتح تيليجرام
- [ ] ابحث عن @MadmoonStore_bot
- [ ] اكتب `/start`
- [ ] اختر خدمة
- [ ] جرب طلب خدمة

---

## 🎯 الخطوات النهائية:

### 1️⃣ إعداد Webhook:
```bash
curl -F "url=https://YOUR_SITE_URL.netlify.app/api/telegram" \
  https://api.telegram.org/bot8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU/setWebhook
```

### 2️⃣ التحقق من Webhook:
```bash
curl https://api.telegram.org/bot8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU/getWebhookInfo
```

### 3️⃣ شحن رصيد SMM:
- [ ] ادخل إلى https://smmsharks.com
- [ ] اشحن رصيداً كافياً

### 4️⃣ شحن أرصدة المستخدمين:
- [ ] من لوحة التحكم → المستخدمين
- [ ] شحن أرصدة للعملاء

### 5️⃣ بدء التسويق:
- [ ] شارك رابط البوت
- [ ] شارك رابط الموقع
- [ ] ابدأ استقبال الطلبات!

---

## ✅ المشروع جاهز عندما:

- [x] جميع ملفات API موجودة
- [x] جميع صفحات React موجودة
- [x] ملفات التكوين جاهزة
- [x] متغيرات البيئة محددة
- [x] البناء المحلي يعمل
- [x] اختبارات API ناجحة
- [x] ربط SMM يعمل
- [x] البوت جاهز
- [ ] تم النشر على Netlify
- [ ] تم إعداد Webhook
- [ ] تم اختبار البوت

---

## 🎉 مبروك! المشروع جاهز للاستخدام!

### روابط مهمة:
- 📱 **البوت:** @MadmoonStore_bot
- 🌐 **الموقع:** https://YOUR_SITE_URL.netlify.app
- 📊 **لوحة التحكم:** https://YOUR_SITE_URL.netlify.app/dashboard
- 🔧 **SMM Panel:** https://smmsharks.com

### الدعم:
- 📧 Email: support@madmoonstore.com
- 📱 Telegram: @support
