# 🎉 دليل النشر النهائي - MadmoonStore Bot

## ✅ ما تم إنجازه بنجاح:

### 1. **البوت الكامل** 🤖
- بوت تيليجرام متكامل
- قوائم تفاعلية
- نظام طلبات آلي
- تتبع الطلبات

### 2. **الموقع الاحترافي** 🌐
- تصميم عصري
- لوحة تحكم متقدمة
- متجاوب مع جميع الأجهزة
- واجهة عربية

### 3. **قاعدة البيانات** 💾
- جداول كاملة
- بيانات تجريبية
- اتصال Supabase نشط

### 4. **الربط مع SMM** 🔗
- متصل بـ SMM Sharks
- رصيد: $6.99
- مزامنة تلقائية للخدمات
- تنفيذ تلقائي للطلبات

### 5. **ملفات جاهزة للنشر** 📦
- `madmoonstore-lite.tar.gz` (28MB)
- `madmoonstore-full.tar.gz` (56MB)
- جميع الملفات المطلوبة

---

## 🚀 خطوات النشر (5 دقائق فقط):

### الخطوة 1: تحميل الملف
```
اختر: madmoonstore-lite.tar.gz (28MB)
```

### الخطوة 2: فك الضغط
- استخرج الملفات على جهازك

### الخطوة 3: الرفع على Netlify
1. اذهب إلى: https://app.netlify.com/drop
2. اسحب المجلد وأفلته
3. انتظر النشر (1-2 دقيقة)
4. انسخ الرابط

### الخطوة 4: إضافة المتغيرات
اذهب إلى: Site settings → Environment variables

أضف:
```
TELEGRAM_BOT_TOKEN = 8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU
SMM_API_URL = https://smmsharks.com/api/v2
SMM_API_KEY = 01b815347b66b2fe9527d631b98bbb3a
NEXT_PUBLIC_SUPABASE_URL = https://zdjzdgxwhtjedknrzxmx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY = sb_publishable_VGUQhIqd0T6kN-PVN8I1gw_W7ZYO3-B
SUPABASE_SERVICE_ROLE_KEY = sb_secret_Yg6OV3hl7Ie1fYN0xuebcQ_nIsnBu4p
VITE_SUPABASE_URL = https://zdjzdgxwhtjedknrzxmx.supabase.co
VITE_SUPABASE_ANON_KEY = sb_publishable_VGUQhIqd0T6kN-PVN8I1gw_W7ZYO3-B
```

### الخطوة 5: إعداد Webhook
استبدل `YOUR_SITE_URL` برابط موقعك:

```bash
curl -F "url=https://YOUR_SITE_URL.netlify.app/api/telegram" \
  https://api.telegram.org/bot8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU/setWebhook
```

### الخطوة 6: ابدأ!
افتح تيليجرام واكتب `/start` في @MadmoonStore_bot

---

## 🎯 روابط مهمة بعد النشر:

- **الموقع:** `https://YOUR_SITE_URL.netlify.app`
- **لوحة التحكم:** `https://YOUR_SITE_URL.netlify.app/dashboard`
- **الخدمات:** `https://YOUR_SITE_URL.netlify.app/services`
- **الطلبات:** `https://YOUR_SITE_URL.netlify.app/orders`
- **المستخدمين:** `https://YOUR_SITE_URL.netlify.app/users`
- **الإعدادات:** `https://YOUR_SITE_URL.netlify.app/settings`
- **البوت:** @MadmoonStore_bot

---

## 💡 ماذا تفعل بعد النشر؟

### 1️⃣ مزامنة الخدمات
1. افتح `/settings`
2. اضغط "مزامنة الخدمات من SMM"
3. انتظر حتى تنتهي المزامنة

### 2️⃣ شحن أرصدة
1. افتح `/users`
2. ابحث عن المستخدم
3. اضغط "شحن رصيد"
4. أدخل المبلغ

### 3️⃣ ضبط هامش الربح
1. افتح `/settings`
2. عدّل "هامش الربح" (مثلاً 20%)
3. اضغط "حفظ"
4. أعد مزامنة الخدمات

### 4️⃣ اختبار البوت
1. افتح @MadmoonStore_bot
2. اكتب `/start`
3. جرب طلب خدمة تجريبية

### 5️⃣ ابدأ التسويق
1. شارك رابط البوت مع العملاء
2. شارك رابط الموقع
3. ابدأ في كسب الأرباح!

---

## 📊 نظام الربح:

### كيف تكسب المال؟

1. **اشترِ بسعر منخفض:**
   - من SMM Sharks (مزودك)
   - مثلاً: متابعين انستقرام = $3/1000

2. **بعِ بسعر أعلى:**
   - للعملاء عبر البوت
   - مثلاً: متابعين انستقرام = $5/1000

3. **الربح:**
   - $5 - $3 = $2 ربح لكل 1000 متابع
   - هامش ربح: 40%

### مثال عملي:

| الخدمة | سعر الشراء | سعر البيع | الربح | الهامش |
|--------|-----------|-----------|-------|--------|
| متابعين انستقرام (1000) | $3.00 | $5.00 | $2.00 | 40% |
| لايكات انستقرام (1000) | $1.50 | $2.50 | $1.00 | 40% |
| متابعين تيك توك (1000) | $5.00 | $8.00 | $3.00 | 37.5% |

---

## 🔧 المتغيرات المطلوبة (ملخص):

```
TELEGRAM_BOT_TOKEN = 8775530532:AAEc5us6jGpcOgSJF2owv-BJIIV57QNjJnU
SMM_API_URL = https://smmsharks.com/api/v2
SMM_API_KEY = 01b815347b66b2fe9527d631b98bbb3a
NEXT_PUBLIC_SUPABASE_URL = https://zdjzdgxwhtjedknrzxmx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY = sb_publishable_VGUQhIqd0T6kN-PVN8I1gw_W7ZYO3-B
SUPABASE_SERVICE_ROLE_KEY = sb_secret_Yg6OV3hl7Ie1fYN0xuebcQ_nIsnBu4p
VITE_SUPABASE_URL = https://zdjzdgxwhtjedknrzxmx.supabase.co
VITE_SUPABASE_ANON_KEY = sb_publishable_VGUQhIqd0T6kN-PVN8I1gw_W7ZYO3-B
```

---

## 📞 الدعم الفني:

### إذا واجهت مشاكل:

**المشكلة:** البوت لا يستجيب
**الحل:**
1. تحقق من متغير `TELEGRAM_BOT_TOKEN`
2. تأكد من إعداد Webhook
3. راجع سجلات Functions في Netlify

**المشكلة:** الطلبات لا تُنفذ
**الحل:**
1. تحقق من `SMM_API_KEY`
2. راجع رصيد SMM
3. تأكد من اتصال API

**المشكلة:** الموقع لا يعمل
**الحل:**
1. تحقق من جميع متغيرات البيئة
2. راجع سجلات النشر
3. أعد النشر

---

## 🎉 مبروك!

الآن لديك:

✅ بوت تيليجرام احترافي
✅ موقع ويب متكامل
✅ لوحة تحكم متقدمة
✅ ربط مع SMM Sharks
✅ قاعدة بيانات كاملة
✅ نظام إدارة شامل
✅ كل شيء جاهز للعمل!

---

## 🚀 ابدأ الآن!

1. حمل الملف: `madmoonstore-lite.tar.gz`
2. ارفعه على Netlify
3. أضف المتغيرات
4. أعد Webhook
5. ابدأ في كسب الأرباح!

**النجاح ينتظرك! 💰🎯**
